package com.javainuse.dao;

import com.javainuse.model.Employee;

public interface EmployeeDao {
	void insertEmployee(Employee cus);
	void deleteEmployeeById(String empid);
}