package com.javainuse.service;

import com.javainuse.model.Employee;

public interface EmployeeService {
	void insertEmployee(Employee emp);
	void deleteEmployeeById(String empid);
}