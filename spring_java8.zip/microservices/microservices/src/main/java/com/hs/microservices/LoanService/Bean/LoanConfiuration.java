package com.hs.microservices.LoanService.Bean;

public class LoanConfiuration {

	private int maximum;
	private int minimum;  
	
	protected LoanConfiuration() {
		super();
	}

	public LoanConfiuration(int maximum, int minimum) {
		super();
		this.maximum = maximum;
		this.minimum = minimum;
	}
	
	public int getMaximum() {
		return maximum;
	}
	
	public int getMinimum() {
		return minimum;
	}
	
	
}
