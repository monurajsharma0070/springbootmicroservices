package com.hs.microservices.LoanService.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired; 
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController; 
import com.hs.microservices.LoanService.Bean.LoanConfiuration;
import com.hs.microservices.LoanService.Configuration.Configuration;
import com.hs.microservices.LoanService.DTO.LoansDTO;
import com.hs.microservices.LoanService.services.LoansServices;

@RestController
public class LoansServiceController {

	@Autowired
	private Configuration configuration;
	
	@Autowired
	LoansServices loanServices;
	
	@GetMapping("/loanConfiguration")
	public LoanConfiuration rettrieveLoanConfiguration()
	{
		return new LoanConfiuration(configuration.getMaximum(),configuration.getMinimum());
	}
	
	@PostMapping("/myLoans")
	public List<LoansDTO> getLoanDetails(@RequestBody LoansDTO Loans) {
		List<LoansDTO> loans = loanServices.getLoanDetails(Loans.getCustomerId());
		if (loans != null ) {
			return loans;
		}else {
			return null;
		} 
	}
}
