package com.hs.InterviewCodingPrepation;

public class FactorialExample {

	public static void main(String[] args) {
		 
		int noFactWant=6;
		int fact=1;
		
		for(int i=1;i<=noFactWant;i++)
		{
			fact=fact * i;
		}

		System.out.println("factorial of No "+noFactWant+" is :"+fact);
		
		System.out.println(15/2);
	}

	
}
