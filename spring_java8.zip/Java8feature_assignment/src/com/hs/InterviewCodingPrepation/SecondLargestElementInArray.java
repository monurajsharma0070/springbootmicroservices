package com.hs.InterviewCodingPrepation;

public class SecondLargestElementInArray {

	public static void main(String[] args) {
		
		int a[]={1,2,5,6,7,9,10,20,2,1,100,99};  
		int b[]={1,2,3,3,5,4,5};  
		System.out.println(retrunSecondLargestElement(b));

	}

	private static int retrunSecondLargestElement(int[] a) {
		 
		int n=a.length;
		int largest=0;
		int secondLargest=0;
		
		for(int i=0; i<n; i++)
		{
			if(a[i]>largest)
			{
				secondLargest=largest;
				largest=a[i];
				
			}else if(a[i]>secondLargest && a[i]!=largest)
			{
				secondLargest=a[i];
			}
		}
		return secondLargest;
	}

}
