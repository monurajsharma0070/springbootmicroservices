package com.hs.InterviewCodingPrepation;

public class RemoveConsecutiveDuplicateValue {

	public static void main(String[] args) {
		 
		String text = "aabbccdd";
		
		String removeDuplicate=removeConseDuplicateElement(text);
		
		System.out.println(removeDuplicate);

	}

	private static String removeConseDuplicateElement(String text) 
	{
		int length=text.length(); 
		if(length <= 0)
		{
			return text;
		}
		String result="";
		
		for(int i=0; i<length; i++)
		{
			if(result.length()==0 || text.charAt(i)!=result.charAt(result.length()-1))
			{
				result+=text.charAt(i);
			}
		}
		return result;
	}

}
