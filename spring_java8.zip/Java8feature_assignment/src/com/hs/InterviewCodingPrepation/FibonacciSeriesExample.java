package com.hs.InterviewCodingPrepation;

public class FibonacciSeriesExample {

	public static void main(String[] args) {
		 
		int totalNos=10; 
        printFibonacciSeries(totalNos);
	}

	private static void printFibonacciSeries(int totalNos) 
	{
		 int num1=0,num2=1;
		 int counter=0;
		 
		 while(counter < totalNos)
		 {
			 System.out.println(num1+" "); 
			 int num3=num1+num2;
			 num1=num2;
			 num2=num3;
			 counter++;
		 }
		
	}

}
