package com.hs.CollectionCoding;

import java.security.KeyStore.Entry;
import java.util.ArrayList;
import java.util.Map;
import java.util.WeakHashMap;

public class WeakHashMapExample {

	public static void main(String[] args) {

		Map<Key,String> map=new WeakHashMap<Key,String>();
		Key key1=new Key("ACTIVE");
		Key key2=new Key("InACTIVE");
		map.put(key1, "HR Department");
		map.put(key2, "Finanace Department");
		key1=null;
		System.gc(); 
		 
		for(java.util.Map.Entry<Key, String> entry : map.entrySet())
		{
			System.out.println(entry.getKey()+"::::"+entry.getValue());
		}
	}

}

class Key
{
	private String key; 
	public Key(String key) {
        this.key = key;
    }
    public String getKey() {
        return key;
    }
    public void setKey(final String key) {
        this.key = key;
    }
}