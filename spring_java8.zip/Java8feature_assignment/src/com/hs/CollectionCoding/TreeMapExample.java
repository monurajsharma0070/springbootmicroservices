package com.hs.CollectionCoding;

import java.util.HashMap;
import java.util.TreeMap;

public class TreeMapExample {

	public static void main(String[] args) {

		TreeMap<Integer,String> map=new TreeMap<Integer, String>();
		//HashMap<Integer,String> map=new HashMap<Integer, String>();
		map.put(null, null);
		
	}

}
