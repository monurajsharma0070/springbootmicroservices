package com.hs.CollectionCoding;

import java.util.PriorityQueue;

public class PriorityQueueExample {

	public static void main(String[] args) {
	 
		PriorityQueue<String> queue=new PriorityQueue<String>();
		queue.add("1");
		queue.add("3");
		queue.add("4");
		queue.add("7");
		queue.add("2");
		queue.add("8");
		queue.add("9");
		queue.add("0");
		
		System.out.println(queue);
		System.out.println(queue.poll());
		System.out.println(queue.poll());
		System.out.println(queue.poll());
		System.out.println(queue.poll());
		System.out.println(queue.peek());

	}

}
