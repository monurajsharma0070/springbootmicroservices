package com.hs.CollectionCoding;

import java.util.Hashtable;
import java.util.LinkedHashMap;

public class HashTableExample {

	public static void main(String[] args) {

		Hashtable<Integer,String> lmap=new Hashtable<Integer,String>(); 
		lmap.put(1, null);
		lmap.put(2, null);
		System.out.println(lmap);
	}

}
