package com.hs.staticExample;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.temporal.TemporalAdjusters;
import java.util.OptionalInt;
import java.util.stream.Stream;

public class StaticBlockExample {

	public static void main(String[] args) {

     OptionalInt max=Stream.of(10,34,89,0,89,78,100).mapToInt(a->a).max();

     System.out.println(max.getAsInt());
     
    int count= (int) Stream.of ( " Hello " , "" , " , " , " world " , " ! " ).filter(String::isEmpty).count();
     
    System.out.println(count);
	}
 
	 
}
