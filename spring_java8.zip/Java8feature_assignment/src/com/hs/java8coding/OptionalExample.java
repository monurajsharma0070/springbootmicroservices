package com.hs.java8coding;

import java.util.Arrays;
import java.util.OptionalInt;

public class OptionalExample {

	public static void main(String[] args) {
		 
		OptionalInt max=Arrays.stream(new int [] {1,10,2,8,9,7}).max();
		System.out.println(max);
		int max2=Arrays.stream(new int [] {}).max().orElse(0);
		System.out.println(max2);
		
		/*
		 * int i=10,j=290;
		 * 
		 * i=i+j; j=i-j; i=i-j; System.out.println(i+"  "+j);
		 */
 
	}

}
