package com.hs.java8coding;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class OddNoAndTheirFrequencyTest {

	public static void main(String[] args) {
		Integer arr[]={1,2,3,3,5,4,5,6,7};
		Stream<Integer> stream=Stream.of(arr);
		Map<Integer,Long> OddNoAndTheirFrequency=(Map<Integer, Long>) stream.filter(n->!(n%2 == 0))
				.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
        System.out.println("Odd nos and their frequency : "+OddNoAndTheirFrequency);
        
        List<String> listS=new ArrayList<String>();
        
        for(int i=0;i<arr.length;i++)
        {
        	int count=0;
        	if(arr[i]%2!=0)
        	{
        		System.out.println(arr[i]);
        	}
        }
	}

}
