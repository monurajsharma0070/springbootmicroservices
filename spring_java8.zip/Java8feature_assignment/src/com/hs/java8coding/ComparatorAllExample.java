package com.hs.java8coding;

public class ComparatorAllExample {

	public static void main(String[] args) {

	}

}
