package com.hs.java8coding;

import java.util.Arrays;

public class InterMediateAndTerminalOpJav8Example {

	public static void main(String[] args) {

		Arrays.stream(new int [] {1,10,7})
				.map(i->{
					
					System.out.println("Doubling "+i);
					return i*2;
				});
		
		int sum=Arrays.stream(new int [] {1,10,2})
		.map(i->{
			
			System.out.println("Doubling "+i);
			return i*2;
		}).sum();

		System.out.println(sum);
	}

}
