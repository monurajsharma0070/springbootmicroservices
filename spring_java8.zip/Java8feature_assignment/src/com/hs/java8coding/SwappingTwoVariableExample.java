package com.hs.java8coding;

public class SwappingTwoVariableExample {

	public static void main(String[] args) {

		int x=10,y=20;
		
		System.out.println("Before swapping : "+" x: "+x+" y :"+y);
		x=x-y;
		y=x+y;
		x=y-x;
		
		System.out.println("After swapping : "+" x: "+x+" y :"+y);
				
	}

}
