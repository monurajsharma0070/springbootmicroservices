package com.hs.java8coding;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class Java8ReduceMethodExample {

	public static void main(String[] args) {

		Integer sumOf7No=28;
		List<Integer> numbers = Arrays.asList(8,9,10);
		
		Optional<Integer> sumOf7Nos=numbers.stream().reduce((sum,nextVal)->sum+nextVal);
		System.out.println("Sum of 7 nos using accumulator:: "+sumOf7Nos);
		
		
		Integer sum=numbers.stream().reduce(sumOf7No,(cursum,nextVal)->cursum+nextVal);
		System.out.println("Sum of 7 nos using Identity :: "+sum);
		
		Integer sumWithCombine=numbers.stream().reduce(sumOf7No,(cursum,nextVal)->cursum+nextVal,Integer::sum);
		System.out.println("Sum of 7 nos using Combine :: "+sumWithCombine);
	}

}
