package com.hs.streamAllFunction.Examples;

import java.util.List;
import java.util.stream.Collectors;

public class FlatMapExample {

	public static void main(String[] args) {
		
		List<Customer> list=Customer.getAll();
		System.out.println(list);
		
		List<String> emailList=list.stream()
				.map(cust->cust.getEmail()).collect(Collectors.toList());
		
		System.out.println("Email List : "+emailList);

		List<List<String>> phonelList=list.stream()
				.map(cust->cust.getPhones()).collect(Collectors.toList());
		
		
		System.out.println("Phone List : "+phonelList);
		
		List<String> phonelListF=list.stream()
				.flatMap(cust->cust.getPhones().stream()).collect(Collectors.toList());
		
		
		System.out.println("Phone List : "+phonelListF);
	}

}
