package com.hs.streamAllFunction.Examples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class SanyogProblemSolution {

	public static void main(String[] args) {
		 
	 List<Pincode> pinCodeList1=Arrays.asList(new Pincode(123),new Pincode(456));
	 List<Pincode> pinCodeList2=Arrays.asList(new Pincode(987),new Pincode(654));
	 List<Pincode> pinCodeList3=Arrays.asList(new Pincode(789),new Pincode(567));
		
     Prmaddress prmaddress1=new Prmaddress("test primary 123",pinCodeList1);
     ArrayList<Prmaddress> prmAddList=new ArrayList<Prmaddress>();
     prmAddList.add(prmaddress1);
     
     Prmaddress prmaddress2=new Prmaddress("test primary 456",pinCodeList2);
     ArrayList<Prmaddress> prmAddList2=new ArrayList<Prmaddress>();
     prmAddList2.add(prmaddress2);
     
     SecndAddress secndAddres1=new SecndAddress("test secondary 123",pinCodeList2);
     ArrayList<SecndAddress> secndAddresList=new ArrayList<SecndAddress>();
     secndAddresList.add(secndAddres1);
     
     SecndAddress secndAddres2=new SecndAddress("test secondary 909",pinCodeList1);
     ArrayList<SecndAddress> secndAddresList2=new ArrayList<SecndAddress>();
     secndAddresList2.add(secndAddres2);
     
     Employee emp1=new Employee(1,"hitesh",50, prmAddList, secndAddresList);
     Employee emp2=new Employee(2,"Rajesh",51, prmAddList, secndAddresList);
     Employee emp3=new Employee(3,"Kumar",52, prmAddList2, secndAddresList2);
     Employee emp4=new Employee(4,"Raju",49, prmAddList, secndAddresList); 
     ArrayList<Employee> empList=new ArrayList<Employee>();
     empList.add(emp1);
     empList.add(emp2);
     empList.add(emp3);
     empList.add(emp4); 
     
     Optional<Pincode> pinList= empList.stream().filter(emp -> emp.getAge()>50).
     flatMap(emp -> emp.getPrmAddressList().stream())
     .flatMap( pincode -> pincode.getPinCodeList().stream()).findFirst(); 
			
     System.out.println(pinList);
	}

}

class Employee
{
	private int id;
	private String name;
	private int age;
	private List<Prmaddress> prmAddressList;
	private List<SecndAddress> secndAddresses;
	
	public Employee(int id, String name, int age, List<Prmaddress> prmAddressList, List<SecndAddress> secndAddresses) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.prmAddressList = prmAddressList;
		this.secndAddresses = secndAddresses;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public List<Prmaddress> getPrmAddressList() {
		return prmAddressList;
	}
	public void setPrmAddressList(List<Prmaddress> prmAddressList) {
		this.prmAddressList = prmAddressList;
	}
	public List<SecndAddress> getSecndAddresses() {
		return secndAddresses;
	}
	public void setSecndAddresses(List<SecndAddress> secndAddresses) {
		this.secndAddresses = secndAddresses;
	}
	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", age=" + age + ", prmAddressList=" + prmAddressList
				+ ", secndAddresses=" + secndAddresses + "]";
	}
	 
}

class Prmaddress
{
	private String street;
	private List<Pincode> pinCodeList;	
	public Prmaddress(String street, List<Pincode> pinCodeList) {
		super();
		this.street = street;
		this.pinCodeList = pinCodeList;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public List<Pincode> getPinCodeList() {
		return pinCodeList;
	}
	public void setPinCodeList(List<Pincode> pinCodeList) {
		this.pinCodeList = pinCodeList;
	}
	@Override
	public String toString() {
		return "Prmaddress [street=" + street + ", pinCodeList=" + pinCodeList + "]";
	} 
}
class SecndAddress
{
	private String street;
	private List<Pincode> pinCodeList;		
	public SecndAddress(String street, List<Pincode> pinCodeList) {
		super();
		this.street = street;
		this.pinCodeList = pinCodeList;
	}
	public String getStreet() {
		return street;
	}
	public void setStreet(String street) {
		this.street = street;
	}
	public List<Pincode> getPinCodeList() {
		return pinCodeList;
	}
	public void setPinCodeList(List<Pincode> pinCodeList) {
		this.pinCodeList = pinCodeList;
	}
	@Override
	public String toString() {
		return "SecndAddress [street=" + street + ", pinCodeList=" + pinCodeList + "]";
	} 
}
class Pincode
{
	private long pinCode;

	public Pincode(long pinCode) {
		super();
		this.pinCode = pinCode;
	}

	public long getPinCode() {
		return pinCode;
	}

	public void setPinCode(long pinCode) {
		this.pinCode = pinCode;
	}

	@Override
	public String toString() {
		return "pinCode : " + pinCode ;
	} 
	
}