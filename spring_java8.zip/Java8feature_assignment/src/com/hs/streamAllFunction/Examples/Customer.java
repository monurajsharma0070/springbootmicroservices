package com.hs.streamAllFunction.Examples;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Customer {

	private int id;
	private String name;
	private String email;
	private List<String> phones;
	public Customer(int id, String name, String email, List<String> phones) {
		super();
		this.id = id;
		this.name = name;
		this.email = email;
		this.phones = phones;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public List<String> getPhones() {
		return phones;
	}
	public void setPhones(List<String> phones) {
		this.phones = phones;
	}  
	 
	public static List<Customer>  getAll()
	{
		ArrayList<Customer> list=new ArrayList<Customer>();
		list.add(new Customer(1,"Raj","raj@gmail.com",Arrays.asList("1234","456","789")));
		list.add(new Customer(1,"Raju","raju@gmail.com",Arrays.asList("567","900","234")));
		list.add(new Customer(1,"Kaj","kaj@gmail.com",Arrays.asList("567","907","567")));
		list.add(new Customer(1,"Haj","haj@gmail.com",Arrays.asList("666","477756","3333")));
		list.add(new Customer(1,"Paj","Paj@gmail.com",Arrays.asList("5555","4444","67888")));
		return list;
	}
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", email=" + email + ", phones=" + phones + "]";
	}
}
