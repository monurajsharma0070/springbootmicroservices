package com.hs.streamAllFunction.Examples;

import java.util.ArrayList;

public class InterviewQuestionAskCodingAnswer {

	public static void main(String[] args) {

		ArrayList<String> obj1=new ArrayList<String>();
		ArrayList<String> obj2=new ArrayList<String>(); 
		obj1.add("1");
		obj1.add("2"); 
		obj2=obj1; 
		obj2.add("3");
		obj2.add("4"); 
		obj2=null; 
		System.out.println(obj1); 
		
		String name="Jagdish";
		String name1="Jagdish";
		String name2=name;
		String name3=null;
		
		System.out.println(name.equals(name1));
		System.out.println(name3.equals(name));
		System.out.println(name==name1);
		System.out.println(name2==name1);
		 
	}

}
