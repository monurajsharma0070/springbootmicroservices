package com.hs.streamAllFunction.Examples;

import java.util.Arrays;
import java.util.Collections;

public class SortedArrayInDecendingOrder {

	 

	public static void main(String[] args) {
		 
		int numArr [] = new int [] {1,2,3,4,5};
		 Arrays.stream(numArr).
				boxed().sorted(Collections.reverseOrder())
				.mapToInt(Integer :: intValue).forEach(System.out::print);
		//System.out.println(sortArr);
	}

}
