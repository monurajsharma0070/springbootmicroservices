package com.hs.exampleclass;

import java.util.ArrayList;
import java.util.List;

public class Example4 {

	public static void main(String[] args) {
		 
		List<Integer> input = new ArrayList<Integer>(); 
		input.add(7); 
		input.add(35); 
		input.add(78); 
		input.add(6);  
		 
		input.sort((num1,num2)->(num1-num2));
	    input.forEach(num->System.out.println("the number "+num));
		  
	}
	
	 

}
