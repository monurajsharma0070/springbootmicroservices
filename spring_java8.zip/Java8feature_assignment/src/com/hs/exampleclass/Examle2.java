package com.hs.exampleclass;

public class Examle2 {

	public static void main(String[] args) { 
		AdditionTwoNos add=(a,b)->System.out.println("Addtion "+(a+b)); 
			               
		//System.out.println("Addtion "+add.add(10,20));  
			              add.add(0, 20);              
	}

}

@FunctionalInterface  //It is optional  
interface AdditionTwoNos{  
    public void add(int a,int b); 
   // public void subtrack(int a,int b); 
}  
