package com.hs.exampleclass;

public class ThreadExample1 {

	public static void main(String[] args) {
		 
		MyThread t=new MyThread();
		t.start();
	} 
	
}

class MyThread extends Thread {
	  
     public void test()
    {
    	run();
        System.out.println("User Thread or Non-Daemon Thread");
    }
}
