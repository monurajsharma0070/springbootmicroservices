package com.hs.exampleclass.streams;

import java.util.ArrayList;

public class UpdateStudentArrayListData {

	public static void main(String[] args) {

		Student s1=new Student("Gwalior");
		Student s2=new Student("Mumbai");
		Student s3=new Student("Chennai");
		Student s4=new Student("Mumbai");
		ArrayList<Student> sList=new ArrayList<Student>();
		sList.add(s1);
		sList.add(s2);
		sList.add(s3);
		sList.add(s4); 
		int i=updateStudentData(sList);
		System.out.println("Record are updated : "+i);
		System.out.println(sList);

	}
	
	public static int updateStudentData(ArrayList<Student> list)
	{
		int count=0;
		String CITY_CONSTANT="Mumbai";
		for(Student s:list) 
		{
			if(CITY_CONSTANT.equalsIgnoreCase(s.getCity())) 
			{
				count++;
				list.set(list.indexOf(s),new Student("Delhi"));
			}
		}
		return count;
	} 
}

class Student 
{
	private String city;  
	public Student(String city) {
		super();
		this.city = city;
	}
	 
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	@Override
	public String toString() {
		return "Student [city=" + city + "]";
	}  
}
