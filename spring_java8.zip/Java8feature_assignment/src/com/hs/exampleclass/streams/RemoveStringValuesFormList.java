package com.hs.exampleclass.streams;

import java.util.ArrayList;
import java.util.Arrays;

public class RemoveStringValuesFormList {

	public static void main(String[] args) {
		
		ArrayList<String> namesList = new ArrayList<String>(Arrays.asList( "alex", "brian", "charles", "alex") );
        System.out.println(namesList);
        namesList.removeIf( name -> name.equals("alex"));
        System.out.println(namesList); 
	}

}
