package com.hs.exampleclass.streams;

import java.io.UnsupportedEncodingException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.Base64;
import java.util.Date;

public class Base64EncodeDecodeClassTest {

	public static void main(String[] args) throws UnsupportedEncodingException {

		String encode=Base64.getEncoder().encodeToString("hitesh".getBytes("UTF-8"));
		System.out.println("Encode :: "+encode);
		
		byte[] decode=Base64.getDecoder().decode("aGl0ZXNo");
		System.out.println("Decode :: "+new String(decode));	
		
		System.out.println(LocalDateTime.ofInstant ( new  Date().toInstant(), ZoneId.systemDefault()));
		
		System.out.println(new  Date ().toInstant ());
	}

}
