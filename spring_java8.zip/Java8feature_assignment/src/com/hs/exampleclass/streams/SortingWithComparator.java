package com.hs.exampleclass.streams;

import java.util.ArrayList;
import java.util.Collections;

public class SortingWithComparator {

	public static void main(String[] args) {

		ArrayList<Employee> l= new ArrayList<Employee>();
		l.add(new Employee(100,"Katrina")); 
		l.add(new Employee(600,"Kareena")); 
        l.add(new Employee(200,"Deepika")); 
        l.add(new Employee(400,"Sunny")); 
        l.add(new Employee(500,"Alia")); 
        l.add(new Employee(300,"Mallika")); 
        System.out.println("Before sorting");
        System.out.println(l);        
        System.out.println("After sorting");
        Collections.sort(l,(e1,e2)->(e1.getEno() < e2.getEno()) ? -1 : (e1.getEno() > e2.getEno()) ? 1 :0);
        System.out.println(l);
	}

}

class Employee 
{
	int eno; 
	String ename;
	
	public Employee(int eno, String ename) {
		super();
		this.eno = eno;
		this.ename = ename;
	} 

	public int getEno() {
		return eno;
	} 

	public void setEno(int eno) {
		this.eno = eno;
	} 

	public String getEname() {
		return ename;
	} 
	
	public void setEname(String ename) {
		this.ename = ename;
	} 

	@Override
	public String toString() {
		return eno+" : "+ename;
	}  
}