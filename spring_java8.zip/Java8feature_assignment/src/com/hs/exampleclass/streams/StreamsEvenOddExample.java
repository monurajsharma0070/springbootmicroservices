package com.hs.exampleclass.streams;

import java.util.ArrayList;
import java.util.List;

public class StreamsEvenOddExample {

	public static void main(String[] args) {
		 
		 List<Integer> intList=new ArrayList<Integer>();
		 intList.add(1);
		 intList.add(2);
		 intList.add(3); intList.add(4); intList.add(5); intList.add(6);
		 intList.add(7); intList.add(8); intList.add(9); intList.add(10);  
		 intList.stream().filter(n->(n%2==0)).forEach(System.out::println);

	}

}
