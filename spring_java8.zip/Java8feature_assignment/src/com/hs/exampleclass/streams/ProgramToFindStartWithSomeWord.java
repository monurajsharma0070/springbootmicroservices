package com.hs.exampleclass.streams;

import java.util.function.Predicate;

public class ProgramToFindStartWithSomeWord {

	public static void main(String[] args) {

		String[] names={"Sunny","Kajal","Mallika","Katrina","Kareena"};
		Predicate<String> p=s->(s.charAt(0)=='K');
		System.out.println("String start with K ");
		for(String s:names)
		{
			if(p.test(s))
			{
			 System.out.println(s);
			}
		}
	}

}
