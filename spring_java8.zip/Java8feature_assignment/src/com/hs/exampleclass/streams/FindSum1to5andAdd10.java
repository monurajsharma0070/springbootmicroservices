package com.hs.exampleclass.streams;

import java.util.stream.IntStream;

public class FindSum1to5andAdd10 {

	public static void main(String[] args) {

		System.out.println("--2");
        int reduced2 =IntStream.of(1, 2, 3, 4, 5).reduce(10, (x, y) -> x + y);  
        System.out.println(reduced2);
	}

}
