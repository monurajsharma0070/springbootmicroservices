package com.hs.exampleclass.streams;

import java.util.function.Function;

public class RemoveSpaceByFunction {

	public static void main(String[] args) {
		
		String s="durga software solutions hyderabad";
		Function<String,String> f1=s1->s1.replaceAll(" ","");
		System.out.println(f1.apply(s));
		
		String s1="durga software solutions hyderabad";
		Function<String,Integer> f2=s2->s2.length() - s2.replaceAll(" ","").length();
		System.out.println(f2.apply(s1));
	}

} 