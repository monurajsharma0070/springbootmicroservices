package com.hs.exampleclass.streams;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class UniqueSquareOFNos {

	public static void main(String[] args) {

		 List<Integer> intList=new ArrayList<Integer>();
		 intList.add(12);intList.add(22);intList.add(13); 
		 intList.add(12); intList.add(15); intList.add(15);
		 intList.add(18); intList.add(18); intList.add(90); 
		 intList.add(010); 
	}

}
