package com.hs.exampleclass.streams;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

public class StreamFindTotalNosInList {

	public static void main(String[] args) {

		 List<Integer> intList=new ArrayList<Integer>();
		 intList.add(12);intList.add(22);intList.add(13); 
		 intList.add(12); intList.add(15); intList.add(15);
		 intList.add(18); intList.add(18); intList.add(90); 
		 intList.add(010);

		 Long no=intList.stream().count();
		 System.out.println(no);
		 
		 Supplier < LocalDateTime > now =  LocalDateTime::now;
		 System.out.println(now.get());
	}

}
