package com.hs.exampleclass.streams;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.OptionalInt;import java.util.stream.Collector;
import java.util.stream.Collectors;

public class FindEmpAgeGraterThan21 {

	public static void main(String[] args) {

		List<Employees> empLists=createEmployeeList();
		System.out.println("Original List : "+empLists);
		
		List<Employees> modifiedLits=empLists.stream().filter(e->e.getAge()>25).map(e->e).collect(Collectors.toList());
		System.out.println("modifiedLits List : "+modifiedLits);
		
		int nos=(int) empLists.stream().filter(e->e.getAge()>19).count();
		System.out.println("Empoyee whose age grater from 19 : "+nos);
		
		Optional<Employees> modcifiedLits=empLists.stream().filter(e->e.getName().equalsIgnoreCase("Mary")).findAny();
		System.out.println("Empoyee whose name are with 'Marry' : "+modcifiedLits);
		
		OptionalInt maxAge=empLists.stream().mapToInt(e->e.getAge()).max();
		System.out.println("Empoyee max age : "+maxAge);
		
		List<Employees> sorteEmpList=empLists.stream().sorted((e1,e2) -> e1.getAge()-e2.getAge()).collect(Collectors.toList());
		System.out.println("Empoyee sorted list : "+sorteEmpList);
		
		List<String> nameEmpList=empLists.stream().map(Employees :: getName).collect(Collectors.toList());
		String joinName=String.join(",", nameEmpList);
		System.out.println("Empoyee Join with , oprator : "+joinName);
		
		System.out.println("Gr Join with , oprator : "+joinName);
	}
	
	public static List<Employees> createEmployeeList()
    {
        List<Employees> employeeList=new ArrayList<>();
 
        Employees e1=new Employees("John",21);
        Employees e2=new Employees("Martin",19);
        Employees e3=new Employees("Mary",31);
        Employees e4=new Employees("Stephan",18);
        Employees e5=new Employees("Gary",26);
 
        employeeList.add(e1);
        employeeList.add(e2);
        employeeList.add(e3);
        employeeList.add(e4);
        employeeList.add(e5);
 
        return employeeList;
    }

}

class Employees
{
	private String name;
	private int age;
	
	public Employees(String name,int age)
	{
		this.name=name;
		this.age=age; 
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "name=" + name + ", age=" + age;
	}  
}
