package com.hs.exampleclass.streams;

import java.util.ArrayList;
import java.util.List;
import java.util.StringJoiner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamSortExample {

	public static void main(String[] args) {
		 
		 List<Integer> intList=new ArrayList<Integer>();
		 intList.add(12);intList.add(22);intList.add(13); 
		 intList.add(12); intList.add(15); intList.add(15);
		 intList.add(18); intList.add(18); intList.add(90); 
		 intList.add(010);
		 
		// System.out.println(intList.toString());
		 
		// intList.stream().sorted((s1,s2) -> s2.compareTo(s1)).forEach( System.out::println);
		 
		 Stream 
		    .of ( 1 , 2 , 3 , 2 , 1 )
		    .map (s -> s * s)
		    .distinct ()
		    .collect ( Collectors . toList ())
		    .forEach ( System . out :: println);

	}

}
