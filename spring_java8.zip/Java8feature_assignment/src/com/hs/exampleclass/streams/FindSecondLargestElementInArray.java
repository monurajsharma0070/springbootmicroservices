package com.hs.exampleclass.streams;

public class FindSecondLargestElementInArray {

	public static void main(String[] args) {
		 
		int a[]={1,2,5,6,7,9,10,20,2,1,100,99};  
		int b[]={1,2,3,3,5,4,5};  
	//	System.out.println("Second Largest: "+returnSecondLargestElement(a));  
		System.out.println("Second Largest: "+returnSecondLargestElement(b));  

	}
	
	public static int returnSecondLargestElement(int [] intArray)
	{
		/*
		 * int length=intArray.length; int temp;
		 * 
		 * for(int i=0; i<length; i++) { for(int j=i+1; j<length; j++) { if(intArray[i]
		 * > intArray[j]) { temp=intArray[i]; intArray[i]=intArray[j]; intArray[j]=temp;
		 * } } }
		 * 
		 * return intArray[length-2];
		 */
		int length=intArray.length;
		int largest=0;
		int secondLargest=0;
		
		for(int i=0; i<length; i++)
		{
			if(intArray[i]>largest)
			{
				secondLargest=largest;
				largest=intArray[i];
			}else if(intArray[i] > secondLargest && intArray[i]!=largest)
			{
				secondLargest=intArray[i];
			}
		}
		
		return secondLargest;
	} 
}
