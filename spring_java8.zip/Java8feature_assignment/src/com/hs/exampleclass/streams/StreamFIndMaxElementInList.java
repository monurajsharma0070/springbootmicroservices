package com.hs.exampleclass.streams;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class StreamFIndMaxElementInList {

	public static void main(String[] args) {
		
		 List<Integer> intList=new ArrayList<Integer>();
		 intList.add(5);intList.add(22);intList.add(13); 
		 intList.add(20); intList.add(15); intList.add(15);
		 intList.add(50); intList.add(18); intList.add(90); 
		 intList.add(100);

		 int test=intList.stream().max((s1,s2)->s2.compareTo(s1)).get();
		 System.out.println(0%3);
	}

}
