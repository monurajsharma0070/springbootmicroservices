package com.hs.exampleclass;

public class DoubleColExample1 {

	public static void main(String[] args) {
		 Runnable r=DoubleColExample1::m2; 
		 Thread t=new Thread(r);
		 t.start();
		 for(int i=0; i<=10; i++) {
			  System.out.println("Main Thread");  
		 }

	}
	
	public static void m2() {
		 for(int i=0; i<=10; i++) {
			  System.out.println("Child Thread");  
		 }
	}

}
