package com.hs.exampleclass.JODADate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class LocaleDateExample1 {

	public static void main(String[] args) {

		LocalDate localDate=LocalDate.now();
		LocalTime localDateTime=LocalTime.now();
		System.out.println(localDate+":"+localDateTime);
	}

}
