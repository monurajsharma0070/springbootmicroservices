package com.hs.exampleclass;

import java.util.function.Function;

public class FunctionExample1 {

	public static void main(String[] args) {

     Function<String, Integer> fun1=s->(s.length());
     System.out.println("Length of string : "+fun1.apply("Hiteshsharma"));
     System.out.println("Length of string : "+fun1.apply("sharma"));
	}

}
