package com.hs.exampleclass;

import java.util.HashMap;

public class HashMapExample {

	public static void main(String[] args) {
		 
		HashMap<String,String> map=new HashMap<String, String>();
		map.put(null, "hitesh");
		map.put(null, "Sharma");
		map.put(null, "Raj");
		map.put(null, "kumar");
		System.out.println(map);
	}

}
