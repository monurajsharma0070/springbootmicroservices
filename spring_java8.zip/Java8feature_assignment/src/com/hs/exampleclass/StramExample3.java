package com.hs.exampleclass;

import java.util.Arrays;
import java.util.stream.Stream;

public class StramExample3 {

	public static void main(String[] args) {

           String strArr []= {"a","b","c","d","e","f"};
           Stream<String> stream=Arrays.stream(strArr);
           
           stream.forEach(s->System.out.println("the value : "+s));
           Long count=stream.filter(x->"b".equals(x)).count();
           System.out.println("the count : "+count);
	}

}
