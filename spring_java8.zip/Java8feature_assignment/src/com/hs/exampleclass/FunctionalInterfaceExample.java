package com.hs.exampleclass;

import java.util.Iterator;

public class FunctionalInterfaceExample {

public static void main(String [] args)
	{  
	
	     Runnable r=FunctionalInterfaceExample ::method1;			  
		 Thread t=new Thread(r);
		 t.start();
		 for(int i=0; i<2; i++)
		 {
			 System.out.println("Main Thread");
		 } 
	}

	public static void method1()
	{
		 for(int i=0; i<2; i++) 
		 {
			 System.out.println("Child Thread");
		 }
	} 

}

@FunctionalInterface
interface InterF2
{
	public int square(int a);
	default void defMeth1()
	{
	  System.out.println("Inside Default method");
	}
}
