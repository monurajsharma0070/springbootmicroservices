package com.hs.exampleclass;

public class DoubleColExample2 {

	public void m2() 
	{
		System.out.println("From class method");  
	} 
	public static void main(String[] args) {
		 
      Interf1 i1=()->System.out.println("Lamda expression method");
      i1.m1();
      DoubleColExample2 d=new DoubleColExample2();
      Interf1 i2=d::m2;
      i2.m1();
	}

}

@FunctionalInterface
interface internf1
{
	public void m1();
}
