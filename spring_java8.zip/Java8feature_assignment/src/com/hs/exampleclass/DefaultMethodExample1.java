package com.hs.exampleclass;

public class DefaultMethodExample1 implements Left,Right{

	public static void main(String[] args) { 

		DefaultMethodExample1 dm=new DefaultMethodExample1();
		dm.m1();
	}
	
	public void m1()
	{
		//System.out.println("Implements Calss method");
		Right.super.m1();
	}

}

interface Left
{
	default void m1()
	{
		System.out.println("default method from left interface");
	}
}
interface Right
{
	default void m1()
	{
		System.out.println("default method from right interface");
	}
}

