package com.hs.designpattern.adapter;

import java.util.ArrayList;

public class EmployeeAdapter implements TargetInterface {

	ThirdPartyPayrollSystem thirdPartyPayrollSystem=new ThirdPartyPayrollSystem();
	
	public void processCompanySalary(Employee [] empArr)
	{
		ArrayList<Employee> empList=new ArrayList<Employee> ();
		for (Employee employee : empArr) {
		
			empList.add(new Employee(employee.getEmpId(), employee.getName(), employee.getDesignation()));
		}
		
		System.out.println("Adapter covert employe array into employee List "+empList+" and going to process the salary for third party");
		
		thirdPartyPayrollSystem.processSalary(empList);
	}
}
