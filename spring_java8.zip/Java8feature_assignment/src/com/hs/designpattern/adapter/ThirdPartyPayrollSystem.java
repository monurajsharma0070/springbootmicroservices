package com.hs.designpattern.adapter;

import java.util.ArrayList;

public class ThirdPartyPayrollSystem {

	public void processSalary(ArrayList<Employee> empList)
	{
		for (Employee employee : empList) {
			
			System.out.println("\n"+employee.toString()+" :");
			if("Team Leader".equalsIgnoreCase(employee.getDesignation()))
			{
				System.out.println("70000 salaray credit to "+employee.getName()+" account");
				
			}else if("Programmer".equalsIgnoreCase(employee.getDesignation()))
			{
				System.out.println("50000 salaray credit to "+employee.getName()+" account");
				
			}else if("Tester".equalsIgnoreCase(employee.getDesignation()))
			{
				System.out.println("40000 salaray credit to "+employee.getName()+" account");
			}
		}
	}
}
