package com.hs.designpattern.adapter;

public interface TargetInterface {

	public void processCompanySalary(Employee [] empArr);
}
