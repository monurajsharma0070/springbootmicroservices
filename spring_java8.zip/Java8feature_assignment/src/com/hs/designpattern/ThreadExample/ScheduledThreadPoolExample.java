package com.hs.designpattern.ThreadExample;

import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public class ScheduledThreadPoolExample {

	public static void main(String[] args) {

		ScheduledExecutorService schexe=Executors.newScheduledThreadPool(1);	 
		WorkerTread workerTrforead=new WorkerTread("Do the duty by thread");
		schexe.scheduleAtFixedRate(workerTrforead,5,10,TimeUnit.SECONDS);
	}

}

class WorkerTread implements Runnable
{
	private String message; 
	
	public WorkerTread(String message) {
		super();
		this.message = message;
	}



	@Override
	public void run() {
		
		System.out.println(Thread.currentThread().getName()+" Task Started.. at "+new Date());
		processMessage(message);
		System.out.println(Thread.currentThread().getName()+" Task Ended.. at "+new Date());
	} 


	private void processMessage(String message2) {
		
		System.out.println("Process message successfully.."); 
	}
	
}
