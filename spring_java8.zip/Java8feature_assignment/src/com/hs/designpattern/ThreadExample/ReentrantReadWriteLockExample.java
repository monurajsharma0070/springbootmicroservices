package com.hs.designpattern.ThreadExample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ReentrantReadWriteLockExample {

	public static void main(String[] args) {
		 
		Integer arr [] = {21,45,90};
		CustomArrayList<Integer> customArrayList=new CustomArrayList<>(arr);		
		Writer w1=new Writer(customArrayList);
		Reader r1=new Reader(customArrayList);
		
		for(int i=0; i<10; i++)
		{
			new Thread(w1).start();
		}
		
		for(int i=0; i<10; i++)
		{
			new Thread(r1).start();
		}
		
	}

}

class CustomArrayList<E>
{
	private List<E> list=new ArrayList<E>();
	private ReentrantReadWriteLock rWLock=new ReentrantReadWriteLock();
	
	public CustomArrayList(E... initialElements)
	{
		list.addAll(Arrays.asList(initialElements));
	}
	
	public void add(E Element)
	{
		Lock writeLock=rWLock.writeLock();
		writeLock.lock();
		try
		{
			list.add(Element);
		}finally {
			writeLock.unlock();
		}
	}
	
	public E get(int index)
	{
		Lock readLock=rWLock.readLock();
		readLock.lock();
		try
		{
			return list.get(index);
		}finally {
			readLock.unlock();
		}
	}
	
	public int size() {
        Lock readLock = rWLock.readLock();
        readLock.lock(); 
        try {
            return list.size();
        } finally {
            readLock.unlock();
        }
    }
}

class Writer implements Runnable
{
	CustomArrayList<Integer> customArrayList;
	
	public Writer(CustomArrayList<Integer> customArrayList)
	{
		this.customArrayList=customArrayList;
	}
	
	@Override
	public void run() {
		
		Random random=new Random();
		int no=random.nextInt(100);
		System.out.println(Thread.currentThread().getName()+ " -> adding: " + no);
		customArrayList.add(no);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	} 
}

class Reader implements Runnable
{
	CustomArrayList<Integer> customArrayList;
	
	public Reader(CustomArrayList<Integer> customArrayList)
	{
		this.customArrayList=customArrayList;
	}
	
	@Override
	public void run() {
		
		Random random=new Random();
		int index=random.nextInt(customArrayList.size());
		Integer number=customArrayList.get(index);
		System.out.println(Thread.currentThread().getName()+ " -> get: " + number);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	} 
}