package com.hs.designpattern.ThreadExample;

import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class CyclicBarierExample {

	public static void main(String[] args) {
		 
		CyclicBarrier cyclicBarrier=new CyclicBarrier(4);
		Thread t1=new Thread(new PassengerThread(1000,cyclicBarrier),"Naju");
		Thread t2=new Thread(new PassengerThread(2000,cyclicBarrier),"Maju");
		Thread t3=new Thread(new PassengerThread(3000,cyclicBarrier),"Kaju");
		Thread t4=new Thread(new PassengerThread(4000,cyclicBarrier),"Raju");
		t1.start();
		t2.start();
		t3.start();
		t4.start(); 
		cyclicBarrier.reset();
		Thread t5=new Thread(new PassengerThread(1000,cyclicBarrier),"Kumar");
		Thread t6=new Thread(new PassengerThread(2000,cyclicBarrier),"Tumar");
		Thread t7=new Thread(new PassengerThread(3000,cyclicBarrier),"Pumar");
		Thread t8=new Thread(new PassengerThread(4000,cyclicBarrier),"Gumar");
		t5.start();
		t6.start();
		t7.start();
		t8.start();
		
	}

}

class PassengerThread implements Runnable
{
    private int duration;
    private CyclicBarrier cyclicBarrier;  
    
	public PassengerThread(int duration, CyclicBarrier cyclicBarrier) {
		super();
		this.duration = duration;
		this.cyclicBarrier = cyclicBarrier;
	}
 

	@Override
	public void run() {
		
		try 
		{ 
			Thread.sleep(duration);
			System.out.println(Thread.currentThread().getName()+" is arrived..");			
			int barier=cyclicBarrier.await();
			if(barier==0)
			{
				System.out.println("All four passenger has been arrived so Cab is going...");
			}
			
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (BrokenBarrierException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}