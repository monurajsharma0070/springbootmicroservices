package com.hs.designpattern.ThreadExample;

public class ThreadAnadBExample {

	 public static void main(String [] args)
	 {
		 Thread tA=new Thread(new Task1(),"TA Thread");
		 Thread tB=new Thread(new Task1(),"TB Thread");
		 tA.start();
		  
	 }
}

class Task1 implements Runnable
{

	@Override
	public void run() {
		
		try {
			synchronized (this) {  
			wait();
			}
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Executing task.....");
	}
	
}
