package com.hs.designpattern.ThreadExample;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReentrantLock;

public class ReentrantLockEample1 {

	public static void main(String[] args) {
 
		ReentrantLock lock=new ReentrantLock();
		Worker w1=new Worker("Job1", lock);
		Worker w2=new Worker("Job2", lock);
		Worker w3=new Worker("Job3", lock);
		Worker w4=new Worker("Job4", lock);
		
		Executor executor=Executors.newFixedThreadPool(5);
		executor.execute(w1);
		executor.execute(w2);
		executor.execute(w3);
		executor.execute(w4);
	}

}

class Worker implements Runnable
{
	String job;
	ReentrantLock lock;  
	
	public Worker(String job, ReentrantLock lock) {
		super();
		this.job = job;
		this.lock = lock;
	} 
	
	@Override
	public void run() {
		try {
			executingTask();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private void executingTask() throws InterruptedException {
		 
		System.out.println("Trying to getting lock..");
		boolean tryToGotLock=lock.tryLock();	
		if(tryToGotLock)
		{
			try {
				System.out.println("Lock taking the task :" + job);
				System.out.println("Doing their work...");
				Thread.sleep(8000);
			} finally {
				lock.unlock();
			} 
			System.out.println("Finish their work and release lock..");
		}else {
			System.out.println("Lock did not take so, doing some ordinary work.."); 
		}
	}
	
}
 