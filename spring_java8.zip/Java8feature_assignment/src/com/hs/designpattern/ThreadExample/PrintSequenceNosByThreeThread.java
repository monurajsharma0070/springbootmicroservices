package com.hs.designpattern.ThreadExample;

public class PrintSequenceNosByThreeThread {

	final static int MAX_NO_THREAD=20;
	
	public static void main(String[] args) {

		PrintSequenceNosByThreeThread obj=new PrintSequenceNosByThreeThread();
		
		Thread t1=new Thread(new NumberRunnaleWithSync(obj, 0),"T1");
		Thread t2=new Thread(new NumberRunnaleWithSync(obj, 1),"T2");
		Thread t3=new Thread(new NumberRunnaleWithSync(obj,2),"T3");
		t1.start();
		t2.start();
		t3.start();
		
	}
	
	

}


/*
 * class NumberRunnaleWithWaitnN implements Runnable {
 * PrintSequenceNosByThreeThread prntObj; int threadNumber; static int number=0;
 * public NumberRunnaleWithWaitnN(PrintSequenceNosByThreeThread obj,int tNumber)
 * { this.prntObj=obj; this.threadNumber=tNumber; }
 * 
 * @Override public void run() {
 * 
 * synchronized (prntObj) { while(number <
 * PrintSequenceNosByThreeThread.MAX_NO_THREAD-2) { while(number % 2 !=
 * threadNumber) { try { prntObj.wait(); } catch (Exception e) { // TODO: handle
 * exception } }
 * System.out.println(Thread.currentThread().getName()+" :: "+(++number));
 * prntObj.notifyAll(); } } }
 * 
 * }
 */


  class NumberRunnaleWithSync implements Runnable 
  {
	  PrintSequenceNosByThreeThread prntObj;
	  int threadNumber; 
	  static int number=0;
	  public NumberRunnaleWithSync(PrintSequenceNosByThreeThread obj,int tNumber) 
	  {
	   this.prntObj=obj; this.threadNumber=tNumber; 
	  }
  
  @Override public void run() {
  
  while(number < PrintSequenceNosByThreeThread.MAX_NO_THREAD) { 
	  synchronized(prntObj) 
	  { 
		  if(number % 3 == threadNumber && number < PrintSequenceNosByThreeThread.MAX_NO_THREAD)
		  {
            System.out.println(Thread.currentThread().getName()+" :: "+(++number)); 
          } 
	  } 
	     
  }
          
  }
  
  } 