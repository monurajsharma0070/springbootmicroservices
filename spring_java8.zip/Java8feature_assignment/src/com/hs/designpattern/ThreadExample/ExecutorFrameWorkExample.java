package com.hs.designpattern.ThreadExample;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ExecutorFrameWorkExample {

	public static void main(String[] args) {
	 
		//ExecutorService service1=Executors.newSingleThreadExecutor(); 
		//ExecutorService service1=Executors.newFixedThreadPool(2); 
		ExecutorService service1=Executors.newCachedThreadPool();
		for(int i=0; i<100; i++)
		{
		  service1.submit(new Task(""+i));	
		}
	}

}

class Task implements Runnable
{
	String task;
	public Task(String task)
	{
		this.task=task;
	}
	@Override
	public void run() {
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		System.out.println(task+ " executing by Thread :: "+Thread.currentThread().getName());
	} 
}
