package com.hs.designpattern.ThreadExample;

import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class FutureObjectDemo {

	private static final ExecutorService threadpool=Executors.newFixedThreadPool(3);
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		FactorialCalculator task =new FactorialCalculator(10);

		Future<Long> future=threadpool.submit(task);
		System.out.println("Task is submitted ......");
		
		if(!future.isDone())
		{
			System.out.println("Task is not completed yet ......");
			Thread.sleep(1);
			
		}
		
		System.out.println("Task is completed lets check value of factorial ......");
		
		long fact=(long) future.get();
		
		System.out.println("The value of factorial  is ......"+fact);
		
		threadpool.shutdown();
	}

}

class FactorialCalculator  implements Callable
{

	private int number;  
	public FactorialCalculator(int number) {
		super();
		this.number = number;
	} 

	@Override
	public Object call()  {
		
		long output=0; 
		try {
			output=factorial(number);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return output;
	}

	private long factorial(int number) throws InterruptedException {
		
		if(number < 0 )
		{
			throw new IllegalArgumentException("Number must be greater than zero"); 
		}
		
		int result =1;
		while(number > 0)
		{
			Thread.sleep(1);
			result=result*number;
			number--;
		}
		return result;
	} 
}