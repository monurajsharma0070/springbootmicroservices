package com.hs.designpattern.composite;

public class Leaf implements IComponent {

	private String name;
	private String designation;
	private String department; 
	
	public Leaf(String name, String designation, String department) {
		super();
		this.name = name;
		this.designation = designation;
		this.department = department;
	} 

	@Override
	public void showHierarchy() {
		
		System.out.println(name+" :: "+designation+" :: "+department);
	}

}
