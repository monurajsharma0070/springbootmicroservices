package com.hs.designpattern.composite;

public interface IComponent {

	void showHierarchy(); 
}
