package com.hs.designpattern.composite;

import java.util.ArrayList;
import java.util.List;

public class Composite implements IComponent {

	private String name;
	private String designation;
	private String department; 
	List<IComponent> componant=new ArrayList(); 
	
	public Composite(String name, String designation, String department) {
		this.name = name;
		this.designation = designation;
		this.department = department;
	}

	public void addComponant(IComponent com)
	{
		componant.add(com);
	}
	
	@Override
	public void showHierarchy() {  
		
		System.out.println(name);
		for(IComponent com:componant)
		{
			com.showHierarchy();
		}
	}

}
