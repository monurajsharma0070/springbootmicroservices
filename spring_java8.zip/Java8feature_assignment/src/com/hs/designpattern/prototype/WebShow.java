package com.hs.designpattern.prototype;

public class WebShow implements PrototypeCapable {

	private String name; 
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	@Override
    public WebShow clone() throws CloneNotSupportedException {
        System.out.println("Cloning Webshow object..");
        return (WebShow) super.clone();
    } 
	 
	@Override
	public String toString() {
		return "Webshow";
	}
}
