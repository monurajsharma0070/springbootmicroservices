package com.hs.designpattern.prototype;


public class TestPrototypeClass {

	public static void main(String[] args) throws CloneNotSupportedException {
		 
		String movieProtoType=PrototypeFactory.getInstance(PrototypeFactory.MOVIE).toString();
		System.out.println(movieProtoType);
		
		String songsProtoType=PrototypeFactory.getInstance(PrototypeFactory.SONGS).toString();
		System.out.println(songsProtoType);		
		
		String webshowProtoType=PrototypeFactory.getInstance(PrototypeFactory.WEBSHOW).toString();
		System.out.println(webshowProtoType);

	}

}
