package com.hs.designpattern.prototype;

public interface PrototypeCapable extends Cloneable {

	public PrototypeCapable clone() throws CloneNotSupportedException;
}
