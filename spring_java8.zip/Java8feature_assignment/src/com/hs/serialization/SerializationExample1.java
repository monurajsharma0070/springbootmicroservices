package com.hs.serialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerializationExample1 {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		Address a1=new Address("MP","gwalior");
		Address a2=new Address("MP","Indore");
		Address a3=new Address("MP","jabalpur");
		Employee emp1 =new Employee(2011,"John",a1);
        Employee emp2 =new Employee(2211,"Jerry",a2);
        Employee emp3 =new Employee(2012,"Sam",a3);
        
        FileOutputStream fout=new FileOutputStream("D:/hitesh/serilization/output.txt");
        ObjectOutputStream out=new ObjectOutputStream(fout);
        out.writeObject(emp1);
        out.writeObject(emp2);
        out.writeObject(emp3);
        out.flush();
        out.close();
        System.out.println("Serialization is been successfully executed");
        
        ObjectInputStream in=new ObjectInputStream(
        		new FileInputStream("D:/hitesh/serilization/output.txt"));
        
        Employee e1=(Employee) in.readObject();
        Employee e2=(Employee) in.readObject();
        Employee e3=(Employee) in.readObject();
        
        System.out.println("De-Serialization is been successfully executed");
        
        System.out.println(e1.id+" "+e1.name);
        System.out.println(e2.id+" "+e2.name);
        System.out.println(e3.id+" "+e3.name);
	}

}
class Employee implements Serializable{
    private static final long serialVersionUID = 1L; //Serial Version UID
    int id;
    String name;
    Address address;
    public Employee(int id, String name, Address address) {
          this.id = id;
          this.name = name; 
          this.address=address;
    }
}
class Address
{
	String state;
	String city;
	public Address(String state, String city) {
		super();
		this.state = state;
		this.city = city;
	}
	
	
}