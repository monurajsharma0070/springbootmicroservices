package com.hs.Cloning;

public class ExaMain1 {

	public static void main(String[] args) {
		 
		 

	}

}
