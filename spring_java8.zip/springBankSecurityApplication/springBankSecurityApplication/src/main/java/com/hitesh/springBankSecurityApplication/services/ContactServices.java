package com.hitesh.springBankSecurityApplication.services;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hitesh.springBankSecurityApplication.DTOModel.ContactDTO;
import com.hitesh.springBankSecurityApplication.model.Contact;
import com.hitesh.springBankSecurityApplication.repository.ContactRepository;
import com.hitesh.springBankSecurityApplication.utility.UtilityComponant;

@Service
public class ContactServices {

	@Autowired
	private ContactRepository contactRepository;
	
	//@PreFilter("filterObject.contactEmail == 'hitesh2@gmail.com' ")
	
	/*
	 * //@PostFilter("filterObject.contactEmail == 'hitesh2@gmail.com' ")
	 * 
	 * @PreFilter("filterObject.contactEmail == 'hitesh2@gmail.com' ")
	 */
	public ContactDTO saveContactInquiryDetails(ContactDTO contactDto) {		
		Contact contact=new Contact();
		contact.setContactId(getServiceReqNumber());
		contact.setCreateDt(new java.sql.Date(System.currentTimeMillis()));
		contact.setContactName(contactDto.getContactName());
		contact.setContactEmail(contactDto.getContactEmail());
		contact.setMessage(contactDto.getMessage());
		contact.setSubject(contactDto.getSubject());
		ContactDTO contactDTO=UtilityComponant.getModelMapper().map(contactRepository.save(contact),ContactDTO.class); 
		return contactDTO;
	}

	private String getServiceReqNumber() {
	    Random random = new Random();
	    int ranNum = random.nextInt(999999999 - 9999) + 9999;
	    return "SR"+ranNum;
	}
}
