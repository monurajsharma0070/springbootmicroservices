package com.hitesh.springBankSecurityApplication.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hitesh.springBankSecurityApplication.DTOModel.AccountsDTO;
import com.hitesh.springBankSecurityApplication.model.Accounts;
import com.hitesh.springBankSecurityApplication.repository.AccountsRepository;
import com.hitesh.springBankSecurityApplication.utility.UtilityComponant;

@Service
public class AccountServices {
	
	@Autowired
	private AccountsRepository accountsRepository;  
	
	public AccountsDTO getAccountDetails(int customertId) {
		Accounts accounts = accountsRepository.findByCustomerId(customertId);
		AccountsDTO accountsDTO=UtilityComponant.getModelMapper().map(accounts, AccountsDTO.class); 
		return accountsDTO;
	} 
}
