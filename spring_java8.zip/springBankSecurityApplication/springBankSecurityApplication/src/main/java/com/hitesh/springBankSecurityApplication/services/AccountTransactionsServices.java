package com.hitesh.springBankSecurityApplication.services;

import java.lang.reflect.Type;
import java.util.List;

import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hitesh.springBankSecurityApplication.DTOModel.AccountTransactionsDTO;
import com.hitesh.springBankSecurityApplication.model.AccountTransactions;
import com.hitesh.springBankSecurityApplication.repository.AccountTransactionsRepository;
import com.hitesh.springBankSecurityApplication.utility.UtilityComponant;

@Service
public class AccountTransactionsServices {

	@Autowired
	private AccountTransactionsRepository accountTransactionsRepository;
	
	public List<AccountTransactionsDTO> getBalanceDetails(int custId) {
		List<AccountTransactions> accountTransactions = accountTransactionsRepository.
				findByCustomerIdOrderByTransactionDtDesc(custId);
		if (accountTransactions != null ) {
			 Type listType = new TypeToken<List<AccountTransactionsDTO>>(){}.getType();
			 List<AccountTransactionsDTO> accountTransactionsList = UtilityComponant.getModelMapper().map(accountTransactions,listType);
			 return accountTransactionsList;	
		}else {
			return null;
		}
	}
}
