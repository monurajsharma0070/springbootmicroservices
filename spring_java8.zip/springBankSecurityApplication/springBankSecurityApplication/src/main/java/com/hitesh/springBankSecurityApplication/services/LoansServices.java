package com.hitesh.springBankSecurityApplication.services;

import java.lang.reflect.Type;
import java.util.List;

import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hitesh.springBankSecurityApplication.DTOModel.LoansDTO;
import com.hitesh.springBankSecurityApplication.model.Loans;
import com.hitesh.springBankSecurityApplication.repository.LoanRepository;
import com.hitesh.springBankSecurityApplication.utility.UtilityComponant;

@Service
public class LoansServices {

	@Autowired
	private LoanRepository loanRepository;
	
	public List<LoansDTO> getLoanDetails(int custId) {
		List<Loans> LoansList = loanRepository.findByCustomerIdOrderByStartDtDesc(custId);
		if (LoansList != null && !LoansList.isEmpty() ) {
			 Type listType = new TypeToken<List<LoansDTO>>(){}.getType();
			 List<LoansDTO> loansDTOList = UtilityComponant.getModelMapper().map(LoansList,listType);
			 return loansDTOList;	
		}else {
			return null;
		}
	}
}
