package com.hitesh.springBankSecurityApplication.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.hitesh.springBankSecurityApplication.model.Accounts;

@Repository
public interface AccountsRepository extends CrudRepository<Accounts,Long> {

	Accounts findByCustomerId(int customerId);
}
