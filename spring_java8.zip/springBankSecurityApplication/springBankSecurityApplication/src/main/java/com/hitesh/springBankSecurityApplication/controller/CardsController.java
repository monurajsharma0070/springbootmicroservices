package com.hitesh.springBankSecurityApplication.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hitesh.springBankSecurityApplication.DTOModel.CardsDTO;
import com.hitesh.springBankSecurityApplication.DTOModel.CustomerDTO;
import com.hitesh.springBankSecurityApplication.ExceptionHandle.ResourceNotFoundException;
import com.hitesh.springBankSecurityApplication.services.CardsServices;

@RestController
public class CardsController {
	
	@Autowired
	private CardsServices cardsServices;
	
	@PostMapping(value="/myCards")
	public List<CardsDTO> getAllCardDetails(@Valid @RequestBody CustomerDTO customer) throws ResourceNotFoundException {  
		List<CardsDTO> cardsList=cardsServices.getAllCards(customer.getId());
		if(!cardsList.isEmpty()) {
		  return cardsList;	
		}else
		{
			throw new ResourceNotFoundException(customer.getId()+"");
		}
	}
	
	//@GetMapping(value="/myCardDetails")
	@GetMapping(value= "/myCardDetails", produces = { MediaType.APPLICATION_JSON_VALUE,
			MediaType.APPLICATION_XML_VALUE})
	public CardsDTO geCardDetails(@Valid @RequestBody CardsDTO cardDTO) throws ResourceNotFoundException {  
		CardsDTO cardDetails=cardsServices.getCardDetails(cardDTO.getCardNumber());
		if(cardDetails!=null) {
		  return cardDetails;	
		}else
		{
			throw new ResourceNotFoundException(cardDTO.getCardNumber()+"");
		}
	}

}
