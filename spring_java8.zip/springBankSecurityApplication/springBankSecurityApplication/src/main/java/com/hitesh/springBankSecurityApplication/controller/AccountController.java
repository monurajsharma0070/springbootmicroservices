package com.hitesh.springBankSecurityApplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hitesh.springBankSecurityApplication.DTOModel.AccountsDTO;
import com.hitesh.springBankSecurityApplication.DTOModel.CustomerDTO;
import com.hitesh.springBankSecurityApplication.model.Accounts;
import com.hitesh.springBankSecurityApplication.model.Customer;
import com.hitesh.springBankSecurityApplication.repository.AccountsRepository;
import com.hitesh.springBankSecurityApplication.services.AccountServices;

@RestController
public class AccountController {
	
	@Autowired
	private AccountServices accountsServices;
	
	@PostMapping("/myAccount")
	public AccountsDTO getAccountDetails(@RequestBody CustomerDTO customer) {
		AccountsDTO accountsDto = accountsServices.getAccountDetails(customer.getId());
		if (accountsDto != null ) {
			return accountsDto;
		}else {
			return null;
		}
	}

}
