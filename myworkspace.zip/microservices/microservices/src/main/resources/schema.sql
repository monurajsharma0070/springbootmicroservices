CREATE TABLE customer (customer_id bigint NOT NULL AUTO_INCREMENT,name varchar(100) NOT NULL,
email varchar(100) NOT NULL,mobile_number varchar(20) NOT NULL,pwd varchar(500) NOT NULL,role varchar(100) NOT NULL,
create_dt date DEFAULT NULL,PRIMARY KEY (customer_id));

CREATE TABLE loans (loan_number bigint NOT NULL AUTO_INCREMENT,customer_id bigint NOT NULL,
start_dt date NOT NULL,loan_type varchar(100) NOT NULL,total_loan bigint NOT NULL,
amount_paid bigint NOT NULL,outstanding_amount bigint NOT NULL,create_dt date DEFAULT NULL,
PRIMARY KEY (loan_number),CONSTRAINT loan_customer_ibfk_1 FOREIGN KEY (customer_id) 
REFERENCES customer (customer_id) ON DELETE CASCADE);