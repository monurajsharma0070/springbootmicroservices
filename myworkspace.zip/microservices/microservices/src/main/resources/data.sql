INSERT INTO customer (name,email,mobile_number,pwd,role,create_dt)
VALUES ('Hitesh','hitesh1@gmail.com','9876548337', '$2a$12$ZYZzsDoi8NU3fSOMsVhKFe3aevDv5uIJycuIZ0bzHuWMGkC/Ncxbi','admin',CURDATE());
INSERT INTO customer (name,email,mobile_number,pwd,role,create_dt)
VALUES ('Rajesh','hitesh2@gmail.com','9875648337', '$2a$12$ZYZzsDoi8NU3fSOMsVhKFe3aevDv5uIJycuIZ0bzHuWMGkC/Ncxbi','admin',CURDATE());
INSERT INTO customer (name,email,mobile_number,pwd,role,create_dt)
VALUES ('Kumar','hitesh3@gmail.com','9877648337', '$2a$12$ZYZzsDoi8NU3fSOMsVhKFe3aevDv5uIJycuIZ0bzHuWMGkC/Ncxbi','user',CURDATE());
INSERT INTO customer (name,email,mobile_number,pwd,role,create_dt)
VALUES ('Nitya','hitesh4@gmail.com','9875648337', '$2a$12$ZYZzsDoi8NU3fSOMsVhKFe3aevDv5uIJycuIZ0bzHuWMGkC/Ncxbi','user',CURDATE());

INSERT INTO loans ( customer_id, start_dt, loan_type, total_loan, amount_paid, outstanding_amount, create_dt)
VALUES ( 1, '2020-10-13', 'Home', 200000, 50000, 150000, '2020-10-13');
INSERT INTO loans ( customer_id, start_dt, loan_type, total_loan, amount_paid, outstanding_amount, create_dt)
VALUES ( 2, '2020-06-06', 'Vehicle', 40000, 10000, 30000, '2020-06-06');
INSERT INTO loans ( customer_id, start_dt, loan_type, total_loan, amount_paid, outstanding_amount, create_dt)
VALUES ( 1, '2018-02-14', 'Home', 50000, 10000, 40000, '2018-02-14');
INSERT INTO loans ( customer_id, start_dt, loan_type, total_loan, amount_paid, outstanding_amount, create_dt)
VALUES ( 1, '2018-02-14', 'Personal', 10000, 3500, 6500, '2018-02-14');