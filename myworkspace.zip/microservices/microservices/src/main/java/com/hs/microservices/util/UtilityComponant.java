package com.hs.microservices.util;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

@Component
public class UtilityComponant {
	 
	public static ModelMapper getModelMapper()
	{
		return new ModelMapper(); 
	} 

}
