package com.hs.streamAllFunction.Examples;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StringJoinExample {

	public static void main(String[] args) {

		List<String> str = Arrays.asList("Welcome", "to", "TechGeekNext");
		
		String strNew=str.stream().map(String :: valueOf)
				.collect(Collectors.joining("-"));
		
		System.out.println(strNew);
	}

}
