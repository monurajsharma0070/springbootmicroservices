package com.hs.serialization;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class SerializationInheritanceExample {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		
		subclass subclass=new subclass(10,20);
		System.out.println("i = " + subclass.i);
        System.out.println("j = " + subclass.j);
        
        FileOutputStream fout=new FileOutputStream("D:/hitesh/serilization/abc.ser");
        ObjectOutputStream out=new ObjectOutputStream(fout);
        out.writeObject(subclass);
        out.flush();
        out.close();
        System.out.println("The object has been serialized");
        
        ObjectInputStream in=new ObjectInputStream(
        		new FileInputStream("D:/hitesh/serilization/abc.ser"));
        
        subclass subclass1=(subclass) in.readObject();
        in.close();
        System.out.println("The object has been deserialized");
        System.out.println("i = " + subclass1.i);
        System.out.println("j = " + subclass1.j);
		
	}

}
class superclass implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	int i;
    public superclass(int i) {
         this.i = i;
    }
    public superclass() {
       //  i = 50;
         System.out.println("Superclass constructor called");
         
   }
}
class subclass extends superclass {
    /**
	 * 
	 */
	private static final long serialVersionUID = 2L;
	int j;
    public subclass(int i, int j) {
          super(i);
          this.j = j;
    }
    
     private void writeObject(ObjectOutputStream out) throws IOException {
        throw new NotSerializableException();
     }
	 private void readObject(ObjectInputStream in) throws IOException {
	        throw new NotSerializableException();
	 }
} 