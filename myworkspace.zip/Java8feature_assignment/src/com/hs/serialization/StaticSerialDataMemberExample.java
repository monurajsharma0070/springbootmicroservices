package com.hs.serialization;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class StaticSerialDataMemberExample implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	static int i=100;
	public static void main(String[] args) throws IOException, ClassNotFoundException {

		StaticSerialDataMemberExample obj=new StaticSerialDataMemberExample();
		FileOutputStream fout=new FileOutputStream("D:/hitesh/serilization/staticdata.ser");
	    ObjectOutputStream out=new ObjectOutputStream(fout);
        out.writeObject(obj);
        out.flush();
        out.close();
        System.out.println("The object has been serialized and then value ::"+i);
        i=900;
        ObjectInputStream in=new ObjectInputStream(
        		new FileInputStream("D:/hitesh/serilization/staticdata.ser"));
        obj=(StaticSerialDataMemberExample) in.readObject();
        in.close();
        System.out.println("The object has been de-serialized and then value ::"+i);
	}

}
