package com.hs.designpattern.ThreadExample;

import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

public class ProducerAndConsumerProblem {

	public static void main(String[] args) {

		List<Integer> list=new Vector<Integer>();
		int SIZE=5;
		
		Thread t1=new Thread(new Producer1(list, SIZE));
		Thread t2=new Thread(new Consumer1(list));
		t1.start();
		t2.start();
	}

}

class Producer1 implements Runnable
{
	List<Integer> sharedList;
	int SIZE;
	public Producer1(List<Integer> sharedList,int size) {
		super();
		this.sharedList = sharedList;
		this.SIZE=size;
	}

	@Override
	public void run() {
		
		for(int i=1; i<10; i++)
		{
			try {
				produce(i);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private void produce(int i) throws InterruptedException
	{
		while(sharedList.size() == SIZE) 
		{
			synchronized (sharedList) 
			{
				  System.out.println(Thread.currentThread().getName()+", Queue is full, producerThread is waiting for "
		                    + "consumerThread to consume, sharedQueue's size= "+SIZE);
				  sharedList.wait();
				 
			} 
					
		}
		synchronized (sharedList) {
		System.out.println(Thread.currentThread().getName() +" Produced : " + i);
		sharedList.add(i);
		sharedList.notifyAll();
		}
	}
	
}

class Consumer1 implements Runnable
{
	List<Integer> sharedList;
	
	public Consumer1(List<Integer> sharedList) 
	{
		super();
		this.sharedList = sharedList;
	}
	@Override
	public void run() { 
		
		while(true) {
		  try {
			consume();
			Thread.sleep(100);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		}
	} 
	
	private void consume() throws InterruptedException
	{
		while(sharedList.size() ==0) 
		{
			synchronized (sharedList) 
			{
				 
				 System.out.println(Thread.currentThread().getName()+", Queue is empty, consumerThread is waiting for "
                         + "producerThread to produce, sharedQueue's size= 0");
				 sharedList.wait();
				 
			} 
		}
		synchronized (sharedList) {
		Thread.sleep((long)(Math.random() * 2000));
		int rval=sharedList.remove(0);
		System.out.println("Consumer consume the value :: "+rval);		
		sharedList.notifyAll();
		}
	}
}
 