package com.hs.designpattern.ThreadExample;

import java.util.concurrent.CountDownLatch;

public class CountDownLatchExample {

	public static void main(String[] args) throws InterruptedException {

		CountDownLatch countDownLatch=new CountDownLatch(2);
		
		DevTeam devteam1=new DevTeam(countDownLatch, "DEV-TEAM-1");
		DevTeam devteam2=new DevTeam(countDownLatch, "DEV-TEAM-2");
		Thread dt1=new Thread(devteam1);
		Thread dt2=new Thread(devteam2);
		dt1.start();
		dt2.start();
		
		countDownLatch.await();
		
		QATeam qaTeam=new QATeam(countDownLatch, "QA-TEAM");
		Thread qt=new Thread(qaTeam);
		qt.start();
	}

}

class DevTeam implements Runnable
{
    private  CountDownLatch caDownLatch;
    private String name;  
    
	public DevTeam(CountDownLatch caDownLatch, String name) {
	super();
	this.caDownLatch = caDownLatch;
	this.name = name; 
	}

	@Override
	public void run() {
		 
		System.out.println("Task assign to dev team : "+name);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
		caDownLatch.countDown();
		System.out.println("Task Finish by dev team : "+name);
	} 
}
class QATeam implements Runnable
{

	private  CountDownLatch caDownLatch;
    private String name;  
    
	public QATeam(CountDownLatch caDownLatch, String name) {
	super();
	this.caDownLatch = caDownLatch;
	this.name = name; 
	}
	
	@Override
	public void run() {
		 
		System.out.println("Task assign to QA team : "+name);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
		caDownLatch.countDown();
		System.out.println("Task Finish by QA team : "+name);
	} 
}