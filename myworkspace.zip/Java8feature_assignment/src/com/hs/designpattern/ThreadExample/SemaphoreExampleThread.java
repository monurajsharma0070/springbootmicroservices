package com.hs.designpattern.ThreadExample;

import java.util.concurrent.Semaphore;

public class SemaphoreExampleThread extends Thread {

	Semaphore semaphore;
	String threadName;  
	public SemaphoreExampleThread(Semaphore semaphore, String threadName) {
		super();
		this.semaphore = semaphore;
		this.threadName = threadName;
	}

	@Override
	public void run() {
		 
		if(threadName.equalsIgnoreCase("Thread-1"))
		{
			System.out.println("Starting ::"+threadName); 
			
			try 
			{
				System.out.println(threadName+" is waiting for permission.."); 
				semaphore.acquire();
				System.out.println(threadName+" got permission.."); 				
				for(int i=0;i<5;i++)
				{
					sharedReource.count++;
					System.out.println(threadName+" ::: "+sharedReource.count); 					
					Thread.sleep(100);
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			semaphore.release();
			System.out.println(threadName+" release the lock"); 	
			
		}else
		{
            System.out.println("Starting ::"+threadName); 
			
			try 
			{
				System.out.println(threadName+" is waiting for permission.."); 
				semaphore.acquire();
				System.out.println(threadName+" got permission.."); 				
				for(int i=0;i<5;i++)
				{
					sharedReource.count--;
					System.out.println(threadName+" ::: "+sharedReource.count); 					
					Thread.sleep(100);
				}
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			semaphore.release();
			System.out.println(threadName+" release the lock"); 
		}
	}
	
	public static void main(String[] args) throws InterruptedException {
		 
       Semaphore semaphore=new Semaphore(1);
       SemaphoreExampleThread t1=new SemaphoreExampleThread(semaphore,"Thread-1");
       SemaphoreExampleThread t2=new SemaphoreExampleThread(semaphore,"Thread-2");
	   t1.start();
	   t2.start();
	   t1.join();
	   t2.join();
	}

}

class sharedReource
{
	static int count=0;
}
