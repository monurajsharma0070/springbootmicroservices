package com.hs.designpattern.ThreadExample;

public class EvenOddWithTwoThread {

	static int  maxSize=20;
	public static void main(String[] args) {

		EvenOddWithTwoThread obj=new EvenOddWithTwoThread();
		Thread Odd=new Thread(new Printer(obj,0),"Odd");
		Thread even=new Thread(new Printer(obj,1),"Even");
		Odd.start();
		even.start();
	}

}

class Printer implements Runnable
{
	EvenOddWithTwoThread evenOddWithTwoThread;
	int tNumber; 
	static int number=0;
	public Printer(EvenOddWithTwoThread evenOddWithTwoThread, int tNumber) {
		super();
		this.evenOddWithTwoThread = evenOddWithTwoThread;
		this.tNumber = tNumber;
	} 

	@Override
	public void run() {
		
		while(number < EvenOddWithTwoThread.maxSize)
		{
			synchronized (evenOddWithTwoThread) 
			{
				if(number % 2 == tNumber && number < EvenOddWithTwoThread.maxSize)
				{
					System.out.println(Thread.currentThread().getName()+" :::: "+(++number));
				}
			}
		}
	}
	
	
	
}
