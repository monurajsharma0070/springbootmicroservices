package com.hs.designpattern.ThreadExample;

import java.util.Random;

public class ThreadLocalExample implements Runnable{

	private static final ThreadLocal<String> tLocal=new ThreadLocal<String>().withInitial(() -> "default");
	
	
	public static void main(String[] args) throws InterruptedException {

		ThreadLocalExample exa=new ThreadLocalExample();
		for(int i=1; i<5; i++)
		{
			Thread t=new Thread(exa,""+i);
			Thread.sleep(new Random().nextInt(1000));
			t.start();
		}
	}


	@Override
	public void run() {
		
		System.out.println("Thread name : "+Thread.currentThread().getName()+" Default Value :"+tLocal.get());
		try {
			Thread.sleep(new Random().nextInt(1000));
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		tLocal.set("modified BY"+Thread.currentThread().getName());
		
		System.out.println("Thread name : "+Thread.currentThread().getName()+" Modified Value :"+tLocal.get());
	}

}
