package com.hs.designpattern.composite;

public class TestDesignPattern {

	public static void main(String[] args) {
		 
		Leaf salesExe1=new Leaf("Hitesh", "Jr sales executive", "sales dept");
		Leaf salesExe2=new Leaf("Rajesh", "Sr sales executive", "sales dept");
		
		Leaf markExe1=new Leaf("Ramu", "Jr markting executive", "marketing dept");
		Leaf markExe2=new Leaf("rahi", "Sr sales executive", "marketing dept");
		
		Leaf TechExe1=new Leaf("ramesh", "Jr programmer", "techenical dept");
		Leaf TechExe2=new Leaf("Hitesh", "Sr programmer", "techenical dept");
		
		Composite salesHead=new Composite("Rama Sharma", "Sales head","sales dept");
		salesHead.addComponant(salesExe1);
		salesHead.addComponant(salesExe2);
		
		Composite markHead=new Composite("Anju Sharma", "Mark head","markting dept");
		markHead.addComponant(markExe1);
		markHead.addComponant(markExe2);		
		
		Composite techHead=new Composite("Ranjish Sharma", "Tech head","techenical dept");
		techHead.addComponant(TechExe1);
		techHead.addComponant(TechExe2);
		
		Composite ceo=new Composite("Kumar viswash", "CEO","Board of Director");
		ceo.addComponant(salesHead);
		ceo.addComponant(markHead);
		ceo.addComponant(techHead);
		
		markHead.showHierarchy();

	}

}
