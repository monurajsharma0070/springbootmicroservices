package com.hs.designpattern.adapter;

public class HRSystem {

	public static Employee [] getAllEmployee()
	{
		Employee [] arr=new Employee [4];
		Employee e1=new Employee(1,"Hitesh","Team Leader");
		Employee e2=new Employee(1,"Kumar","Programmer");
		Employee e3=new Employee(1,"Rajat","Tester");
		Employee e4=new Employee(1,"Rakesh","Team Leader");
		arr[0]=e1;
		arr[1]=e2;
		arr[2]=e3;
		arr[3]=e4;
		return arr; 
	}
	
	public static void main(String [] arr)
	{
		System.out.println("Employee array : "+getAllEmployee());
		TargetInterface target=new EmployeeAdapter();
		target.processCompanySalary(getAllEmployee());
	}
}
