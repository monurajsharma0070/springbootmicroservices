package com.hs.designpattern.prototype;

import java.util.HashMap;
import java.util.Map;

public class PrototypeFactory {

	static final String MOVIE="movie";
	static final String SONGS="songs";
	static final String WEBSHOW="webshow";
	
	private static Map<String,PrototypeCapable> map=new HashMap<String, PrototypeCapable>();
	static
	{	
		map.put(MOVIE,new Movie());
		map.put(SONGS, new Songs());
		map.put(WEBSHOW,new WebShow());
	}
	
	public static PrototypeCapable getInstance(final String s) throws CloneNotSupportedException
	{
		return ((PrototypeCapable)map.get(s)).clone();
	}
}
