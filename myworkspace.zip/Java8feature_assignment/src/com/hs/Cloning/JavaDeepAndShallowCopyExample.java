package com.hs.Cloning;

public class JavaDeepAndShallowCopyExample {

	public static void main(String[] args) throws CloneNotSupportedException {

		Department dept = new Department(1, "HR");

		Employee e1 = new Employee(1, "Hitesh", dept);
		System.out.println("Original Employee : " + e1);

		Employee e2 = (Employee) e1.clone();

		System.out.println("Cloned Employee : " + e2);

		e2.getDepartment().setName("Finance");
        e2.setEmployeeName("Ra");
		System.out.println("Cloned Employee After change Dept : " + e2);
		System.out.println("Original Employee : " + e1);
	}

}

class Employee implements Cloneable {

	private int empoyeeId;
	private String employeeName;
	private Department department;

	public Employee(int id, String name, Department dept) {
		this.empoyeeId = id;
		this.employeeName = name;
		this.department = dept;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		Employee cloned= (Employee) super.clone();
		cloned.setDepartment((Department)cloned.getDepartment().clone());
		return cloned;
	}

	public int getEmpoyeeId() {
		return empoyeeId;
	}

	public void setEmpoyeeId(int empoyeeId) {
		this.empoyeeId = empoyeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Employee [empoyeeId=" + empoyeeId + ", employeeName=" + employeeName + ", department=" + department
				+ "]";
	}
}

class Department implements Cloneable {
	private int id;
	private String name;

	public Department(int id, String name) {
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + "]";
	}
}
