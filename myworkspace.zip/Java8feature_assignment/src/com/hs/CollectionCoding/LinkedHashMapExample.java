package com.hs.CollectionCoding;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class LinkedHashMapExample {

	public static void main(String[] args) {
		 
	    LinkedHashMap<Integer,String> lmap=new LinkedHashMap<Integer,String>();
		lmap.put(1, "raj");
		lmap.put(2, "Paj");
		lmap.put(9, "Kaj");
		lmap.put(6, "haj");
		lmap.put(3, "haj");
		lmap.put(8, "naj");
		lmap.put(null, null);
		lmap.put(null, null);
		System.out.println(lmap);

	}

}
