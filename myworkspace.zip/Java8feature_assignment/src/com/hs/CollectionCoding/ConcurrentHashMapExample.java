package com.hs.CollectionCoding;

import java.util.HashMap;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapExample {
	static int i = 1;
	public static void main(String[] args) {

		//ConcurrentHashMap<String,String> cmap=new ConcurrentHashMap<String, String>();
		
		HashMap<String,String> cmap=new HashMap();
		cmap.put(null, null);
		System.out.println(cmap);
		for (int i = 1; i < 10; i++) {
            i = i + 2;
            System.out.print(i + " ");
        }
	}

}
