package com.hs.exampleclass;

import java.util.function.Predicate;

public class PredicateExample1 {

	public static void main(String[] args) {
		  
		/*
		 * Predicate<String> p1=s->(s.length() > 3);
		 * System.out.println("Length of string is grater than three : "+p1.test(
		 * "Hitesh"));
		 * System.out.println("Length of string is grater than three : "+p1.test("sha"))
		 * ; System.out.println("Length of string is grater than three : "+p1.test(
		 * "vaishnavi"));
		 */
		
		Predicate<Integer> p1=I->(I%2==0);
		System.out.println("No is even  : "+p1.test(10)); 
		System.out.println("No is even  : "+p1.test(9));
	}

}

 
