package com.hs.exampleclass;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class StreamExample2 {

	public static void main(String[] args) {
		List<String> a1=new ArrayList<String>();
		a1.add("hitesh");
		a1.add("sharma");
		a1.add("monu");
		a1.add("raj");
		a1.add("ra");
		a1.add("i"); 
		System.out.println(a1);
		List<String> a2=a1.stream().sorted().collect(Collectors.toList());
		System.out.println(a2);
		List<String> a3=a1.stream().sorted((s2,s1)->s2.compareTo(s1)).collect(Collectors.toList());
		System.out.println(a3);
	}

}
