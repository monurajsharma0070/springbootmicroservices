package com.hs.exampleclass;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ExampleSortStringByJava8 {

	public static void main(String[] args) {

       String str="hitabesh";
       
       str=Stream.of(str.split("")).sorted().collect(Collectors.joining());
        
        
       System.out.println(str);

	}

}
