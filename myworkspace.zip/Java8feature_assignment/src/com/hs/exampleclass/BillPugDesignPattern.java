package com.hs.exampleclass;

public class BillPugDesignPattern {

	public static void main(String[] args) {
		 
		BillPugSingleton obj1=BillPugSingleton.getInstance();
		BillPugSingleton obj2=BillPugSingleton.getInstance();
		System.out.println(obj1.hashCode());
		System.out.println(obj2.hashCode());
	}

}

class BillPugSingleton
{
	private BillPugSingleton() {};
	
	private static class SingletonHelperClass
	{
		private static final BillPugSingleton INSTANCE=new BillPugSingleton();
	}
	
	public static BillPugSingleton getInstance()
	{
		return SingletonHelperClass.INSTANCE;
	}
}