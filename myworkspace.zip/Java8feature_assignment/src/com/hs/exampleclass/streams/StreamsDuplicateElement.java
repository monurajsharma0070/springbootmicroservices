package com.hs.exampleclass.streams;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class StreamsDuplicateElement {

	public static void main(String[] args) {

		ArrayList<Integer> intList = new ArrayList<Integer>();
		intList.add(12);
		intList.add(22);
		intList.add(13);
		intList.add(12); 
		intList.add(10);
		
		ArrayList<Double> strList = new ArrayList<Double>();
		strList.add(10.0);
		strList.add(12.0);
		strList.add(10D);
		strList.add(13D);
		
		ArrayList<Double> newList=removeDuplicates(strList);
		System.out.println(newList);
		/*
		 * // System.out.println(intList); //
		 * intList.stream().distinct().forEach(System.out::println);
		 * 
		 * HashSet<Integer> set=new HashSet<Integer>();
		 * intList.stream().filter(s->(!set.add(s))).forEach(System.out::println);
		 * 
		 * 
		 * //intList.stream().filter(i->(Collections.frequency(intList,i) >
		 * 1)).collect(Collectors.toSet()).forEach(System.out::println);
		 * 
		 * Set<Integer> t=intList.stream().filter(i->(Collections.frequency(intList,i) >
		 * 1)).collect(Collectors.toSet());
		 * 
		 * System.out.println(t);
		 */

	}
	
	public static <T> ArrayList<T> removeDuplicates(ArrayList<T> list)
	{
		ArrayList<T> newList=(ArrayList<T>)list.stream().distinct().collect(Collectors.toList());
		return newList; 
	}

}
