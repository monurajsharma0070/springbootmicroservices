package com.hs.exampleclass.streams;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ReverseIntArray {

	public static void main(String[] args) {
		
		Integer a[]={1,2,5,6,7,9,10,20,2,1,100,99};  
		Integer b[]={44,66,99,77,33,22,55};  
		System.out.println("Second Largest: "+returnReverseIntegerArray(a));  
		System.out.println("Second Largest: "+returnReverseIntegerArray(b));
		
		
	} 

	public static Integer[]  returnReverseIntegerArray(Integer [] intArray)
	{
		List list=Arrays.asList(intArray);
		Collections.reverse(list);
        intArray = new Integer[list.size()];
		return intArray; 
	} 
}
