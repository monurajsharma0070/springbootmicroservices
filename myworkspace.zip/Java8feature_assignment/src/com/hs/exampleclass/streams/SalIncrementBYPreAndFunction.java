package com.hs.exampleclass.streams;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.function.Predicate;import java.util.stream.Collector;
import java.util.stream.Collectors;

public class SalIncrementBYPreAndFunction {

	public static void main(String[] args) {

		ArrayList<Employee2> al=new ArrayList<Employee2>();
		populateEmp(al);
		System.out.println("Before Increment");
		System.out.println(al);
		
		Predicate<Employee2> p=e->e.getSalary()<3500;
		Function<Employee2,Employee2> f=e->{  
			e.salary=e.salary+477; 
			return e; 
		};
		System.out.println("After Increment"); 
		List<Employee2> al2=new ArrayList<Employee2>();
		al2=al.stream().filter(p).map(f).collect(Collectors.toList());
		System.out.println(al2); 
	}
		 
		
	public static void populateEmp(ArrayList<Employee2> l) 
	{
		l.add(new Employee2("Sunny",1000)); 
		l.add(new Employee2("Bunny",2000)); 
		l.add(new Employee2("Chinny",3000)); 
		l.add(new Employee2("Pinny",4000)); 
		l.add(new Employee2("Vinny",5000));
		l.add(new Employee2("Durga",10000)); 
	}

}

class Employee2
{
	String name;
	double salary;
	public Employee2(String name, double salary) {
		this.name = name;
		this.salary = salary;
	} 
	
	public String getName() {
		return name;
	} 
	public void setName(String name) {
		this.name = name;
	} 
	public double getSalary() {
		return salary;
	} 
	public void setSalary(double salary) {
		this.salary = salary;
	} 

	@Override
	public String toString() {
		return name+" :: "+salary;
	}  
}
