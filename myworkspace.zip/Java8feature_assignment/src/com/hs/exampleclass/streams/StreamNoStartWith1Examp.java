package com.hs.exampleclass.streams;

import java.util.ArrayList;
import java.util.List;

public class StreamNoStartWith1Examp {

	public static void main(String[] args) {
		 
		 List<Integer> intList=new ArrayList<Integer>();
		 intList.add(12);intList.add(22);intList.add(13); 
		 intList.add(44); intList.add(15); intList.add(61);
		 intList.add(71); intList.add(18); intList.add(90); 
		 intList.add(010);
		 
		 intList.stream().map(s->(s+"")).filter(s->(s.startsWith("1"))).forEach(System.out::println);

	}

}
