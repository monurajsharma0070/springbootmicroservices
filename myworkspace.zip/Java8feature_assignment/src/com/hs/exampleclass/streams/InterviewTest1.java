package com.hs.exampleclass.streams;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class InterviewTest1 {

	public static void main(String[] args) {
		ArrayList<Integer> intList = new ArrayList<Integer>();
		intList.add(12);
		intList.add(22);
		intList.add(13);
		intList.add(12); 
		intList.add(10);
		
		ArrayList<Integer> newList=removeDuplicates(intList);
		System.out.println(newList);

	}

	public static <T> ArrayList<T> removeDuplicates(ArrayList<T> list)
	{
		ArrayList<T> newList=(ArrayList<T>)list.stream().distinct().collect(Collectors.toList());
		return newList; 
	}

}
