package com.hs.exampleclass.streams;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class FindDuplicate {

	public static void main(String[] args) {

		ArrayList<Integer> intList = new ArrayList<Integer>();
		intList.add(12);intList.add(22);
		intList.add(13);intList.add(12); 
		intList.add(10);intList.add(10);
		intList.add(12);intList.add(22);
		
		intList.stream().distinct().collect(Collectors.toSet()).forEach(System.out :: println);
		
		Set li=intList.stream().filter(a-> Collections.frequency(intList, a) > 1).collect(Collectors.toSet());
		System.out.println(li);
	}

}
