package com.hs.exampleclass.streams;

import java.util.function.Function;

public class FunctionIdentityExample {

	public static void main(String[] args) {
		 
		Function<String,String> function=Function.identity();
		String s2=function.apply("123456");
		System.out.println(s2);
}
}
