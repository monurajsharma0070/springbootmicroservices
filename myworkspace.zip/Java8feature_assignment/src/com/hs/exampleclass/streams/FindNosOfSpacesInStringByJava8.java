package com.hs.exampleclass.streams;

import java.util.function.Function;

public class FindNosOfSpacesInStringByJava8 {

	public static void main(String[] args) {
	
		String s="hitesh sharma hiteshsharma sharna jj iijj";
		Function<String,Integer> f1=f->(f.length() - f.replaceAll(" ","").length());
		System.out.println(f1.apply(s));

	}

}
