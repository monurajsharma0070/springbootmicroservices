package com.hs.exampleclass;

public class StaticMethodExample1 implements test {

	public static void main(String[] args) {
		 
		StaticMethodExample1 st=new StaticMethodExample1();
	 
	} 
	
	 

}

interface test
{
	public static void sum(int a,int b)
	{
		System.out.println("Sum of two variables is : "+(a+b));
	}
}
