package com.hs.exampleclass;

import java.util.function.Predicate;

public class Example1 {

	public static void main(String [] str) {
		
		Predicate<Integer> p=I->(I%2==0);
		 System.out.println("test :"+p.test(10));
		 System.out.println("test :"+p.test(9));
	}
	 
}


interface interf{
	public void sum(int a,int b); 
}