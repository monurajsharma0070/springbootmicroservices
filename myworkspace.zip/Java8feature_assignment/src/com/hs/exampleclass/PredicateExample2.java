package com.hs.exampleclass;

import java.util.function.Predicate;

public class PredicateExample2 {

	public static void main(String[] args) {
		 
		int x []= {0,10,80,40,30,2,5,9,13,15};
		Predicate<Integer> p1=I->(I>10);
		Predicate<Integer> p2=I->(I%2 == 0);
		System.out.println("Nos , which is grater than 10 are : ");
		testCon(p1,x);
		System.out.println("Nos , which is even : ");
		testCon(p2,x);
		System.out.println("Nos , which is even and grater than 10 are : ");
		testCon(p1.and(p2),x);
		System.out.println("The Numbers Not Greater Than 10:"); 
		testCon(p1.negate(), x);
	}
	
	
	public static void testCon(Predicate<Integer> p,int [] x) {
		
		for(int x1:x) 
		{
			if(p.test(x1))
			{
			 System.out.println(x1);
			}
		}
	}

}
