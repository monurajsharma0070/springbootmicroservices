package com.hs.exampleclass;

public class FunctionalInternExample5 {

	int x=10;
	
	public void m2() {
		
		int y=20;
		Interf1 i1=()->{
			
			System.out.println(x);
			System.out.println(y);
			x=30; 
			System.out.println(x);
		};
		
		i1.m1();
		i1.m3();
	}
	public static void main(String[] args) {
		 
		FunctionalInternExample5 f1=new FunctionalInternExample5();
		f1.m2();
	}

}

interface Interf1 {  
	public void m1();
	default void m3() {
		 System.out.println("Default Method");
	}
}