package com.hs.exampleclass;

import java.util.concurrent.Semaphore;

public class SemaphoremExample {

	public static void main(String[] args) {
		SharedPrinter sp = new SharedPrinter();
	    Thread odd = new Thread(new Odd(sp, 10),"Odd");
	    Thread even = new Thread(new Even(sp, 10),"Even"); 
	    even.start();
	    odd.start();

	}

}

class SharedPrinter {

    private Semaphore semEven = new Semaphore(0);
    private Semaphore semOdd = new Semaphore(1);
    
    void printOddNum(int num) {
        try {
            semOdd.acquire();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println(Thread.currentThread().getName() + num);
        semEven.release();

    }

    void printEvenNum(int num) {
        try {
            semEven.acquire();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        System.out.println(Thread.currentThread().getName() + num);
        semOdd.release();
    } 
    
}

class Even implements Runnable {
    private SharedPrinter sp;
    private int max;

    // standard constructor
    public Even(SharedPrinter sp, int max) {
		super();
		this.sp = sp;
		this.max = max;
	}

	@Override
    public void run() {
        for (int i = 2; i <= max; i = i + 2) {
            sp.printEvenNum(i);
        }
    }
}

class Odd implements Runnable {
    private SharedPrinter sp;
    private int max;

    // standard constructors 
    
    @Override
    public void run() {
        for (int i = 1; i <= max; i = i + 2) {
            sp.printOddNum(i);
        }
    }

	public Odd(SharedPrinter sp, int max) {
		super();
		this.sp = sp;
		this.max = max;
	}
}
