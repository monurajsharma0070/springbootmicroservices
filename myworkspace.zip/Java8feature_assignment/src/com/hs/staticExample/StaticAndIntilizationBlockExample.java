package com.hs.staticExample;

public class StaticAndIntilizationBlockExample {

	public static void main(String[] args) {
		 
         new MysubClass();
	}

}
class MyClass
{
	static
	{
		System.out.println("Static block executed >> super class");
	}
	
	{
	 System.out.println("Instance block executed >> super class");
	}
	
	public MyClass()
	{
		System.out.println("Constructor executed >> super class");
	}
	
}
class MysubClass extends MyClass
{
	static
	{
		System.out.println("Static block executed >> sub class");
	}
	
	{
	 System.out.println("Instance block executed >>  sub class");
	}
	
	public MysubClass()
	{
		System.out.println("Constructor executed >>  sub class");
	}
}