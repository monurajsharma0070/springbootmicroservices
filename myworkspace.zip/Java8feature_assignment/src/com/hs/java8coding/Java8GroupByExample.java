package com.hs.java8coding;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.function.Function;import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Java8GroupByExample {

	public static void main(String[] args) {
		 
		List<String> strings = new ArrayList<>();
		strings.add("Hello");
		strings.add("Ram");
		strings.add("Hello");
		strings.add("Sam");
		strings.add("Hello");
		strings.add("Yam");
		strings.add("Hello");
		strings.add("Raj");
		strings.add("Hello");
		strings.add("Raj");
		
		Map<String,Long> countG=strings.stream().
				 collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		System.out.println("Groupby on counting :"+countG);		
		
		Map<String,Long> asendingSortByCount=countG.entrySet().stream()
	            .sorted(Entry.comparingByValue())
	            .collect(Collectors.toMap(e->e.getKey(),e->e.getValue(),
	            (e1,e2)->e2,LinkedHashMap::new));
        System.out.println("Asending order sorted on counting :"+asendingSortByCount);
		
		Map<String,Long> sortByCount=countG.entrySet().stream()
				            .sorted(Entry.<String,Long>comparingByValue().reversed())
				            .collect(Collectors.toMap(e->e.getKey(),e->e.getValue(),
				            (e1,e2)->e2,LinkedHashMap::new));
		System.out.println("Descending order sorted on counting :"+sortByCount);
		
		// Creating List and adding duplicate values.
		List<Stock> stocks = new ArrayList<>();
		stocks.add(new Stock("JP Morgan", 10, 100));
		stocks.add(new Stock("ICICI", 20, 100));
		stocks.add(new Stock("HDFC", 30, 300));
		stocks.add(new Stock("ICICI", 20, 200));
		stocks.add(new Stock("JP Morgan", 10, 100));
		stocks.add(new Stock("JP Morgan", 10, 100));

		
		Map<String,Integer> groupByStokAndSum=stocks.stream()
				.collect(Collectors.groupingBy(Stock::getName, 
						Collectors.summingInt(Stock::getQuantity)));
		
		System.out.println("No of stocks by stock name : "+groupByStokAndSum);
		
		
		Map<String,Map<Integer,Long>> groupByStockNameQuanity=stocks.stream()
		                                    .collect(Collectors.groupingBy(Stock::getName,
		                                    Collectors.groupingBy(Stock::getQuantity
		                                    ,Collectors.counting())));
		                                    
		System.out.println("group by - stock name + quanity : "+groupByStockNameQuanity);
	}

}

class Stock {

	private String name;
	private int quantity;
	private double price;

	public Stock(String name, int quantity) {
		this.name = name;
		this.quantity = quantity;
	}

	public Stock(String name, int quantity, double price) {
		super();
		this.name = name;
		this.quantity = quantity;
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
}
