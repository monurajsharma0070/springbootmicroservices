package com.hs.java8coding;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class ComparatorJava8Example {

	public static void main(String[] args) {

		List<Engineer> engineers1 = getEngineersList();
		// printing engineer objects sorted by id
		System.out.println("Before sorting");
		engineers1.forEach(System.out::println);
		
		Comparator<Engineer> ecok=new Comparator<Engineer>() {
			
			@Override
			public int compare(Engineer e1, Engineer e2) {

				return Integer.valueOf(e1.getId()).compareTo(e2.getId());
			}
		};
		
		Collections.sort(engineers1, ecok);
		System.out.println("\nAfter sorting");
		engineers1.forEach(System.out::println);
	}

	private static List<Engineer> getEngineersList() {
		// creating the List of engineers
		List<Engineer> engineers = new LinkedList<>();
		// adding engineer objects
		engineers.add(new Engineer(100, "Jeo", 100000, false));
		engineers.add(new Engineer(103, "Sunny", 500000, true));
		engineers.add(new Engineer(104, "Zeon", 300000, false));
		engineers.add(new Engineer(105, "Neon", 400000, true));
		engineers.add(new Engineer(102, "Ammon", 200000, false));
		return engineers;
	}
}
class Engineer {

	private int id;
	private String name;
	private long salary;
	private boolean fullTime;

	public Engineer(int id, String name, long salary, boolean fullTime) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.fullTime = fullTime;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getSalary() {
		return salary;
	}

	public void setSalary(long salary) {
		this.salary = salary;
	}

	public boolean isFullTime() {
		return fullTime;
	}

	public void setFullTime(boolean fullTime) {
		this.fullTime = fullTime;
	}

	@Override
	public String toString() {
		return "Engineer [id=" + id + ", name=" + name + ", salary=" + salary + ", fullTime=" + fullTime + "]";
	}
}