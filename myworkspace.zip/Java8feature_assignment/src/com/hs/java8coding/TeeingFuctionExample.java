package com.hs.java8coding;

import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

public class TeeingFuctionExample {

	public static void main(String[] args) {
		List<Employe> employeeList = Arrays.asList(
                new Employe(1, "A", 100),
                new Employe(2, "B", 200),
                new Employe(3, "C", 300),
                new Employe(4, "D", 400)); 
		
		//HashMap<String,Employe> listM=new HashMap<String, Employe>;
		HashMap<String,Employe>  result=employeeList.stream().collect(
				Collectors.teeing(
				Collectors.maxBy(Comparator.comparing(Employe::getSal)),
				Collectors.minBy(Comparator.comparing(Employe::getSal)), 
				(e1,e2)-> {
					HashMap<String,Employe> listM=new HashMap<String, Employe>();
					listM.put("MAX",e1.get());
					listM.put("MIN",e2.get());
					return listM;
				}));
		
		System.out.println(result);

	}

}

class Employe
{
	private int id;
	private String name;
	private int sal; 
	public Employe(int id, String name, int sal) {
		super();
		this.id = id;
		this.name = name;
		this.sal = sal;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSal() {
		return sal;
	}
	public void setSal(int sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Employe [id=" + id + ", name=" + name + ", sal=" + sal + "]";
	} 
	
}
