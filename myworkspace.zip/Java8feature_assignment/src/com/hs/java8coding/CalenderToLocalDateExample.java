package com.hs.java8coding;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Calendar;
import java.util.Date;

public class CalenderToLocalDateExample {

	public static void main(String[] args) {
		 
		Calendar cal=Calendar.getInstance();
		
		Date indate=cal.getTime();
		
		LocalDate ldat=indate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
		
		System.out.println(ldat);

	}

}
