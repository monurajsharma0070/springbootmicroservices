package com.hs.java8coding;

import java.util.ArrayList;
import java.util.Date;
import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;
import java.util.stream.Collectors;

public class Java8FlatMappingExample {

	public static void main(String[] args) {

		LineItem lineItem1 = new LineItem(1001, "Item 1", new Date(2010, 07, 01));
		LineItem lineItem2 = new LineItem(1002, "Item 2", new Date(2020, 07, 01));
		LineItem lineItem3 = new LineItem(1003, "Item 3", new Date(2030, 07, 01));
		LineItem lineItem4 = new LineItem(1004, "Item 4", new Date(2040, 07, 01));
		LineItem lineItem5 = new LineItem(1005, "Item 5", new Date(2050, 07, 01));
		List<LineItem> lineItemsList1 = new ArrayList<>();
		lineItemsList1.add(lineItem1);
		lineItemsList1.add(lineItem2);
		lineItemsList1.add(lineItem3);
		lineItemsList1.add(lineItem4);
		lineItemsList1.add(lineItem5);
		Customer customer1 = new Customer(100, "Customer 1", true, "M", lineItemsList1);
		
		LineItem lineItem6 = new LineItem(2001, "Item 6", new Date(2010, 07, 01));
		LineItem lineItem7 = new LineItem(2002, "Item 7", new Date(2020, 07, 01));
		List<LineItem> lineItemsList2 = new ArrayList<>();
		lineItemsList2.add(lineItem6);
		lineItemsList2.add(lineItem7);
		Customer customer2 = new Customer(200, "Customer 2", true, "F", lineItemsList2);
		
		LineItem lineItem8 = new LineItem(2003, "Item 8", new Date(2040, 07, 01));
		LineItem lineItem9 = new LineItem(3004, "Item 9", new Date(2070, 07, 01));
		LineItem lineItem10 = new LineItem(3005, "Item 10", new Date(2200, 07, 01));
		List<LineItem> lineItemsList3 = new ArrayList<>();
		lineItemsList3.add(lineItem8);
		lineItemsList3.add(lineItem9);
		lineItemsList3.add(lineItem10);
		Customer customer3 = new Customer(300, "Customer 3", true, "M", lineItemsList3);
		
		Customer customer4 = new Customer(400, "Customer 4", true, "F", new ArrayList<LineItem>()); 

		List<Customer> customersList = new ArrayList<>();
		customersList.add(customer1);
		customersList.add(customer2);
		customersList.add(customer3);
		customersList.add(customer4);
		 
		 Optional<Customer> CollectorsMaxByExample=customersList.stream()
				 .collect(Collectors.maxBy((e1,e2)-> e1.getId()-e2.getId()));
		 System.out.println("CollectorsMaxByExample :"+CollectorsMaxByExample);
		 
		 Optional<Customer> CollectorsMinByExample=customersList.stream()
				 .collect(Collectors.minBy((e1,e2)-> e1.getId()-e2.getId()));
		 System.out.println("CollectorsMinByExample :"+CollectorsMinByExample);
		 
		 
		 DoubleSummaryStatistics doubleSummaryStatistics =customersList.stream()
				 .collect(Collectors.summarizingDouble(e->e.getId()));
		 System.out.println("doubleSummaryStatistics example :"+doubleSummaryStatistics);
		 
		 Map<String, Set<LineItem>> itemsByGende2=customersList.stream()
				 .collect(Collectors.groupingBy((Customer e)->e.getGender(),
				 Collectors.flatMapping(customer->customer.getLineItems().stream(),Collectors.toSet())));
		 System.out.println("itemsByGende2 example :"+itemsByGende2);
		 
		 Map<Object, Long> itemsCountByGender =customersList.stream()
				 .collect(Collectors.groupingBy(e->e.getGender(),
				  Collectors.flatMapping(cust->cust.getLineItems().stream(), Collectors.counting())));;
		 System.out.println("itemsCountByGender example :"+itemsCountByGender);	
		 
		 Map<Boolean, TreeSet<Customer>> partitionByAgeTreeSet = customersList.stream()
				 .collect(Collectors.partitioningBy( e -> e.getId() > 30
				 , Collectors.toCollection(TreeSet::new)));
		 
	}

}

class LineItem {

	private int itemId;
	private String itemName;
	private Date manfacturedDate;

	public LineItem(int itemId, String itemName, Date manfacturedDate) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.manfacturedDate = manfacturedDate;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Date getManfacturedDate() {
		return manfacturedDate;
	}

	public void setManfacturedDate(Date manfacturedDate) {
		this.manfacturedDate = manfacturedDate;
	}

	@Override
	public String toString() {
		return "LineItem [itemId=" + itemId + ", itemName=" + itemName + ", manfacturedDate=" + manfacturedDate + "]";
	} 
}

class Customer {
	
	private int id;
	private String name;
	private boolean active;
	private String gender;
	private List<LineItem> lineItems;

	public Customer(int id, String name, boolean active, String gender, List<LineItem> lineItems) {
		super();
		this.id = id;
		this.name = name;
		this.active = active;
		this.gender = gender;
		this.lineItems = lineItems;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public List<LineItem> getLineItems() {
		return lineItems;
	}

	public void setLineItems(List<LineItem> lineItems) {
		this.lineItems = lineItems;
	}

	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + "]";
	} 
}