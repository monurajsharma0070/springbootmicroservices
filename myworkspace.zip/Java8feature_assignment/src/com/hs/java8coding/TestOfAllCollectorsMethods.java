package com.hs.java8coding;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors; 

public class TestOfAllCollectorsMethods {

	public static void main(String[] args) {

		List<Employee> employeeList = new ArrayList<Employee>();
		employeeList.add(new Employee(100, "Sundar", 47, "North America", 450000));
		employeeList.add(new Employee(200, "Pichai", 25, "North America", 50000));
		employeeList.add(new Employee(300, "Larry", 30, "Asia", 450000));
		employeeList.add(new Employee(400, "Page", 59, "Africa", 450000));
		employeeList.add(new Employee(400, "Raj", 56, "India", 90000));
		 
		
		List<String> nameList=employeeList.stream().
				               map(e->e.getName()).collect(Collectors.toList());		
		System.out.println("List :"+nameList);
		
		Set<Double> resgionSet=employeeList.stream().map(e->e.getSal())
				.collect(Collectors.toSet());
		System.out.println("Set :"+resgionSet);
		
		LinkedList<String> linkedNameList=employeeList.stream().
	               map(e->e.getName()).collect(Collectors.toCollection(LinkedList :: new));		
         System.out.println("LinkedList :"+linkedNameList);
         
         
         Set<String> tereeResgionSet=employeeList.stream().map(e->e.getRegion())
 				.collect(Collectors.collectingAndThen(Collectors.toSet(), Collections::<String> unmodifiableSet));
		 System.out.println("TreeSet :"+tereeResgionSet);
		 
 		  
 		 Set<String> collectingAndThenSet=employeeList.stream().map(e->e.getRegion())
  				.collect(Collectors.collectingAndThen(Collectors.toSet(), Collections::<String> unmodifiableSet));
  		 System.out.println("collectingAndThen  first Example :"+collectingAndThenSet);
  		 
  		 
  		 String maxAgeEmployee=employeeList.stream().
  				 collect(Collectors.collectingAndThen(Collectors.maxBy(Comparator.comparing(Employee :: getAge)), 
  						 (e->e.get().getName())));
   		 System.out.println("collectingAndThen second Example :"+maxAgeEmployee);
   		 
   		 Map<Integer,Employee> toMapExample=employeeList.stream()
   				                            .collect(Collectors.toMap(e->e.getId(),
   				                            		Function.identity(),(old,newo)->newo));
  		 System.out.println("toMapExample Example :"+toMapExample);
  		 
  		 
  		 Integer empIdSumming=employeeList.stream()
                   .collect(Collectors.summingInt((Employee e) -> e.getId()));
         System.out.println("empIdSumming Example :"+empIdSumming);
         
         
         Double avegOfEmpSal=employeeList.stream()
                 .collect(Collectors.averagingDouble((Employee e) -> e.getSal()));
         System.out.println("averagingDouble Example :"+avegOfEmpSal);
         
         
         Long countingExample=employeeList.stream().collect(Collectors.counting());
         System.out.println("countingExample  :"+countingExample);
         
         String joiningExample=employeeList.stream().map(e->e.getName())
        		 .collect(Collectors.joining(","));
         System.out.println("joiningExample  :"+joiningExample);
         
         Map<Object, List<Employee>> grupByRegionList=employeeList.stream()
        		 .collect(Collectors.groupingBy(e->e.getRegion()));
         System.out.println("grupByRegionList List  :"+grupByRegionList);
         
         
         Map<Object, Set<Employee>> grupByRegionSet=employeeList.stream()
        		 .collect(Collectors.groupingBy(e->e.getRegion(),Collectors.toSet()));
         System.out.println("grupByRegionSet Example  :"+grupByRegionSet);
         
         
         Map<Boolean, List<Employee>> partitioningByAge= employeeList.stream()
		 .collect(Collectors.partitioningBy(e->e.getAge()>30));
         System.out.println("partitioningBy Example  :"+partitioningByAge);
         
			
		  List<Employee> collectorsFiltering= employeeList.stream().
		  collect(Collectors.filtering(e -> e.getAge() > 50,Collectors.toList()));
		  System.out.println("Collectors filtering Example  :"+collectorsFiltering);
		  
		  
		  Comparator<Employee> comp=(e1,e2)->e1.getId()-e2.getId();
		  Optional<Employee> optMaxByEmployee= employeeList.stream().
				  collect(Collectors.maxBy(comp));
		  System.out.println("Collectors maxBY Example  :"+optMaxByEmployee.get());
				  
		  Optional<Employee> optMinByEmployee= employeeList.stream().
				  collect(Collectors.minBy(comp));
		  System.out.println("Collectors maxBY Example  :"+optMinByEmployee.get());
			 
		  HashMap<String, Employee> TeeingExample= employeeList.stream()
					 .collect(
					  Collectors.
					  teeing(Collectors.maxBy(Comparator.comparing(Employee::getSal)), 
							  Collectors.minBy(Comparator.comparing(Employee::getSal)),
							  (e1,e2)->
					  {
						  HashMap<String,Employee> map=new HashMap();
						  map.put("MAX",e1.get());
						  map.put("MIN",e2.get());
						  return map;
					  }
							  
							  ));
		 System.out.println("Teeing Example  :"+TeeingExample);
         
	}

}
