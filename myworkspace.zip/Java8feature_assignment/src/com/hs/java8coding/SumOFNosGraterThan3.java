package com.hs.java8coding;

import java.util.Arrays;

public class SumOFNosGraterThan3 {

	public static void main(String[] args) {
		 
		int sum=Arrays.stream(new int [] {1,10,2,1,4,2,8,9,7})
				.filter(i->i>3).map(i->i*2).sum();
		System.out.println(sum);

	}

}

interface DateInterface {
	
	  static void getLocale() {

    }
}