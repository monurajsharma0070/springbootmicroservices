package com.hs.InterviewCodingPrepation;

import java.util.stream.Stream;

public class FindTheMaximumValueInList {

	public static void main(String[] args) {
		 
		Integer arr[]={10,15,8,49,25,98,32,100};
		Stream<Integer> stream=Stream.of(arr); 
		Integer maxNo=stream.max(Integer::compare).get();
		System.out.println(maxNo);

	}

}
