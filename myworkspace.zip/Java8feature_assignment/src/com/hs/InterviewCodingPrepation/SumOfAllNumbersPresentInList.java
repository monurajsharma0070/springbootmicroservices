package com.hs.InterviewCodingPrepation;

import java.util.ArrayList;

public class SumOfAllNumbersPresentInList {

	public static void main(String[] args) {
		 
		ArrayList<Integer> list = new ArrayList<Integer>(); 
        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);
        list.add(50);
        
       int sum= list.stream().mapToInt(e->e).sum();
       System.out.println("Sum of nos"+sum);
       
       
       int doublingSum= list.stream().mapToInt(n->n*n).sum();
       System.out.println("Sum of nos square : "+doublingSum);

	}

}
