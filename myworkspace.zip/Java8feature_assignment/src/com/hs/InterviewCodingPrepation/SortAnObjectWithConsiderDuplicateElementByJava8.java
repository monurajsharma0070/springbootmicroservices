package com.hs.InterviewCodingPrepation;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SortAnObjectWithConsiderDuplicateElementByJava8 {

	public static void main(String[] args) {

		List<Notes> noteLst = new ArrayList<>();
        noteLst.add(new Notes(1, "notes1", 11));
        noteLst.add(new Notes(3, "notes2", 33));
        noteLst.add(new Notes(4, "notes3", 44));
		noteLst.add(new Notes(2, "notes4", 34));
        noteLst.add(new Notes(5, "notes5", 32)); 
        noteLst.add(new Notes(6, "notes4", 36)); 
        noteLst.sort((n1,n2) -> n2.getTagId()-n1.getTagId()); 
        Map<String,Integer> notesMap=noteLst.stream().collect(Collectors.toMap(Notes::getTagName,Notes::getTagId
        		,(o,n)->o,LinkedHashMap::new));
        
        System.out.println(notesMap);
	}

}

