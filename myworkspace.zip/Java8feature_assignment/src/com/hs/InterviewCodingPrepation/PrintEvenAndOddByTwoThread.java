package com.hs.InterviewCodingPrepation;

public class PrintEvenAndOddByTwoThread {

	static int MAX_NUMBER=20;
	public static void main(String[] args) {
		 
		PrintEvenAndOddByTwoThread obj=new PrintEvenAndOddByTwoThread();
		Thread t2=new Thread(new PrintEvenOdd(obj,0),"even");
		Thread t1=new Thread(new PrintEvenOdd(obj,1),"Odd");
		t1.start();
		t2.start();
	}

}

class PrintEvenOdd implements Runnable
{
	PrintEvenAndOddByTwoThread obj;
	int tnumber;
	static int nos=1;;
	public PrintEvenOdd(PrintEvenAndOddByTwoThread obj, int tnumber) {
		super();
		this.obj = obj;
		this.tnumber = tnumber;
	}
	
	@Override
	public void run() {
		
		while(nos < PrintEvenAndOddByTwoThread.MAX_NUMBER)
		{
			synchronized (obj) 
			{
				
				if(nos % 2 == tnumber)
				{
					System.out.println(Thread.currentThread().getName()+" ::: "+(nos++));
				}
			}
			
		}
	}


	
	
}