package com.hs.InterviewCodingPrepation;

import java.util.Optional;
import java.util.stream.Stream;

public class FindFirstElementOfTheList {

	public static void main(String[] args) {
		 
		Integer arr[]={10,15,8,49,25,98,32,100};
		Stream<Integer> stream=Stream.of(arr);
		Optional<Integer> findFirst=stream.findFirst();
		Integer firstNos=findFirst.isPresent() ? findFirst.get() : 0;
		System.out.println(firstNos);
	}

}
