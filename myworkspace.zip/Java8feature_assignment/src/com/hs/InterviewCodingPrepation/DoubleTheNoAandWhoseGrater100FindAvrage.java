package com.hs.InterviewCodingPrepation;

import java.util.ArrayList;
import java.util.OptionalDouble;

public class DoubleTheNoAandWhoseGrater100FindAvrage {

	public static void main(String[] args) {
		
		ArrayList<Integer> list = new ArrayList<Integer>(); 
        list.add(10);
        list.add(20);
        list.add(30);
        list.add(40);
        list.add(50);
        
        OptionalDouble answer=list.stream().mapToInt(n->n*n).filter(n->n>100).average();
        System.out.println(answer);

	}

}
