package com.hs.InterviewCodingPrepation;

public class ThreadPrintNoAsSequenceByThreeThread {

	static int  MAX_NO_COUNT=20;
	public static void main(String[] args) {

		ThreadPrintNoAsSequenceByThreeThread obj=new ThreadPrintNoAsSequenceByThreeThread();
		
		Thread t1=new Thread(new PrintSequenceNumber(obj,0),"T1");
		Thread t2=new Thread(new PrintSequenceNumber(obj,1),"T2");
		Thread t3=new Thread(new PrintSequenceNumber(obj,2),"T3");
		Thread t4=new Thread(new PrintSequenceNumber(obj,3),"T4");
		Thread t5=new Thread(new PrintSequenceNumber(obj,4),"T5");
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t5.start();
	}

}

class PrintSequenceNumber implements Runnable
{
	private ThreadPrintNoAsSequenceByThreeThread obj;
    private int threadNo=0;
    private static int count=0; 
    public PrintSequenceNumber(ThreadPrintNoAsSequenceByThreeThread obj, int threadNo) {
		super();
		this.obj = obj;
		this.threadNo = threadNo;
	} 
    
	@Override
	public void run() {
		 
		while(count<ThreadPrintNoAsSequenceByThreeThread.MAX_NO_COUNT)
		{
			synchronized (obj) 
			{
				if(count%5 == threadNo && count<ThreadPrintNoAsSequenceByThreeThread.MAX_NO_COUNT)
				{
					System.out.println(Thread.currentThread().getName()+" :: "+(++count)); 
				}
				
			}
		}
		
	}



	
}