package com.hs.InterviewCodingPrepation;

import java.util.stream.Stream;

public class FindNumbersStartingWith1 {

	public static void main(String[] args) {

		Integer arr[]={10,15,8,49,25,98,32,100};
		Stream<Integer> stream=Stream.of(arr);		
		//stream.map(s->s+"").filter(a->a.startsWith("1")).forEach(System.out::println);
		stream.filter(a->a.toString().startsWith("10")).forEach(System.out::println);
	}

}
