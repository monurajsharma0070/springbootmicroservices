package com.hs.InterviewCodingPrepation;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindDuplicateNosWithTheirFrequency {

	public static void main(String[] args) {
		List<Integer> myList = Arrays.asList(10,15,8,49,25,98,98,32,15);
		
		Map<Integer,Long> duplicateMapWithFre=myList.stream().filter(a->Collections.frequency(myList,a) > 1)
		.collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
		
		System.out.println(duplicateMapWithFre);
	}

}
