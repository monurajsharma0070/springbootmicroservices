package com.hs.InterviewCodingPrepation;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class FindTheCharWhichIsNotInString {

	public static void main(String[] args) {

      String str="hiteshsharma";    
      for(int i=97; i<=122;i++)
      {
    	  char c=(char) i;
    	  if(str.indexOf(c)==(-1))
    	  {
    	    System.out.print(c);
    	  }
      }
      
       
     

	}

}
