package com.hs.InterviewCodingPrepation;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class FindTheNosWhichIsNotInArray {

	public static void main(String[] args) {

		List<Integer> list = Arrays.asList(2,1,10,4,5,3,8,7,6);
		list.sort((s1,s2) -> s1.compareTo(s2));
		for(int i=1;i<list.size();++i)
		{ 
			if(list.get(i)-list.get(i-1)!=1)
			{
				System.out.println(i+1);
			}
		}
	}

}
