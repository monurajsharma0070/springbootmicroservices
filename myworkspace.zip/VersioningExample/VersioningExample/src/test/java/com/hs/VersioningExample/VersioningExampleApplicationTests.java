package com.hs.VersioningExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VersioningExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
