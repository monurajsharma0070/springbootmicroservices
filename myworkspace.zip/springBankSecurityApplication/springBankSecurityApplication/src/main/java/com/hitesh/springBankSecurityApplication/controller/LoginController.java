package com.hitesh.springBankSecurityApplication.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hitesh.springBankSecurityApplication.DTOModel.AuthenticationRequest;
import com.hitesh.springBankSecurityApplication.DTOModel.AuthenticationResponse;
import com.hitesh.springBankSecurityApplication.utility.JwtUtil;

@RestController
public class LoginController {

	@Autowired
	private AuthenticationProvider authenticationProvider;

	@Autowired
	private JwtUtil jwtTokenUtil;
	
	@PostMapping("/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@Valid @RequestBody AuthenticationRequest authenticationRequest) throws Exception {

		Authentication auth=null;
		try {
			  auth=authenticationProvider.authenticate(
					new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword())
			);
		}
		catch (BadCredentialsException e) {
			throw new Exception("Incorrect username or password", e);
		}
 
		final String jwt = jwtTokenUtil.createToken(auth);

		return ResponseEntity.ok(new AuthenticationResponse(jwt));
	}
}
