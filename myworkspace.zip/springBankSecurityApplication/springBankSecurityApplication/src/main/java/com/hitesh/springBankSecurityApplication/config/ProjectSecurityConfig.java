package com.hitesh.springBankSecurityApplication.config;

import java.util.Arrays;
import java.util.Collections;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.hitesh.springBankSecurityApplication.Filter.AuthoritiesLoggingAfterFilter;
import com.hitesh.springBankSecurityApplication.Filter.AuthoritiesLoggingAtFilter;
import com.hitesh.springBankSecurityApplication.Filter.JWTTokenValidatorFilter;
import com.hitesh.springBankSecurityApplication.Filter.RequestValidationBeforeFilter;
import com.hitesh.springBankSecurityApplication.interceptor.LoginInterceptor;

@Configuration
public class ProjectSecurityConfig extends WebSecurityConfigurerAdapter  {
 
	
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		/*
		 * Default security configuration
		*/
		
//		http.authorizeRequests((requests) -> requests.anyRequest().authenticated());
//		http.formLogin();
//		http.httpBasic();
		
		/*
		 * Custom security configuration as per our requirement 
		*/
		http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).and()
		.cors().configurationSource(new CorsConfigurationSource() {
			@Override
			public CorsConfiguration getCorsConfiguration(HttpServletRequest request) {
				CorsConfiguration config = new CorsConfiguration();
				config.setAllowedOrigins(Collections.singletonList("http://localhost:4200"));
				config.setAllowedMethods(Collections.singletonList("*"));
				config.setAllowCredentials(true);
				config.setAllowedHeaders(Collections.singletonList("*"));
				config.setExposedHeaders(Arrays.asList("Autorization"));
				config.setMaxAge(3600L);
				return config;
			}
		}).and().csrf().disable() 
		   .addFilterBefore(new RequestValidationBeforeFilter(), BasicAuthenticationFilter.class)
	       .addFilterAfter(new AuthoritiesLoggingAfterFilter(), BasicAuthenticationFilter.class)
	       .addFilterBefore(new JWTTokenValidatorFilter(), BasicAuthenticationFilter.class)
	       .addFilterAt(new AuthoritiesLoggingAtFilter(), BasicAuthenticationFilter.class)
		   .authorizeRequests()
		   .antMatchers("/myBalance").authenticated()
		   .antMatchers("/myCards").authenticated()
		   .antMatchers("/myLoans").authenticated()
		   .antMatchers("/myAccount").authenticated()
		   .antMatchers("/notices").permitAll() 
		   .antMatchers("/authenticate").permitAll() 
		   .antMatchers("/contact").permitAll()
		   .antMatchers("/h2-console/**","/login/**").permitAll()
		   .and()
           .headers().frameOptions().sameOrigin()
				/*
				 * .and() .formLogin().loginPage("/login")
				 */
		   .and() 
		   .httpBasic();
		 
		//ignoringAntMatchers("/contact","/h2-console/**").csrfTokenRepository(CookieCsrfTokenRepository.withHttpOnlyFalse())
		/*
		 * Denied all coming request 
		*/
		/*
		 * http.authorizeRequests((requests) -> requests.anyRequest().denyAll());
		 * http.formLogin(); http.httpBasic();
		 */
 		
 		/*
		 * Permit all coming request 
		*/
		/*
		 * http.authorizeRequests((requests) -> requests.anyRequest().denyAll());
		 * http.formLogin(); http.httpBasic();
		 */
	}
	
	/*
	 * @Override protected void configure(AuthenticationManagerBuilder auth) throws
	 * Exception {
	 * 
	 * auth.inMemoryAuthentication().withUser("admin").password("12345").authorities
	 * ("admin").and(). withUser("user").password("12345").authorities("read").and()
	 * .passwordEncoder(NoOpPasswordEncoder.getInstance()); }
	 */
	
	
	/*
	 * @Override protected void configure(AuthenticationManagerBuilder auth) throws
	 * Exception {
	 * 
	 * InMemoryUserDetailsManager userDetailsService = new
	 * InMemoryUserDetailsManager(); UserDetails user
	 * =User.withUsername("admin").password("12345").authorities("admin").build();
	 * UserDetails user1
	 * =User.withUsername("user").password("12345").authorities("read").build();
	 * userDetailsService.createUser(user); userDetailsService.createUser(user1);
	 * auth.userDetailsService(userDetailsService);
	 * 
	 * }
	 */ 
	
	/*
	 * @Bean public UserDetailsService userDetailsService(DataSource dataSource) {
	 * 
	 * return new JdbcUserDetailsManager(dataSource); }
	 */
	 
	  @Bean
	  PasswordEncoder passwordEncoder() {
		  
		  return new BCryptPasswordEncoder();
	  }
	   
}
