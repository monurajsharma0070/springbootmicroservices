package com.hitesh.springBankSecurityApplication.controller;

import java.util.List; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import com.hitesh.springBankSecurityApplication.DTOModel.NoticeDTO;
import com.hitesh.springBankSecurityApplication.services.NoticeServices;

@RestController
public class NoticesController {
	
	@Autowired
	private NoticeServices noticeServices;
	
	@GetMapping(value="/notices",produces = {MediaType.APPLICATION_XML_VALUE})
	public List<NoticeDTO> getNotices(String input) {
		
		List<NoticeDTO> notices=noticeServices.getNotices(input);
		if(!notices.isEmpty()) {			
			return notices;
		}else {
			
			return null;
		}
	}

}
