package com.hitesh.springBankSecurityApplication.utility;

import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import javax.crypto.SecretKey;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Service;
import com.hitesh.springBankSecurityApplication.constants.SecurityConstants;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Service
public class JwtUtil { 

	/*
	 * private Boolean isTokenExpired(String token) { return
	 * extractExpiration(token).before(new Date()); }
	 */
	    public String createToken(Authentication authentication) {

	    	SecretKey key = Keys.hmacShaKeyFor(SecurityConstants.JWT_KEY.getBytes(StandardCharsets.UTF_8));
			String jwt = Jwts.builder().setIssuer("Hitesh Sharma").setSubject("JWT Token")
						.claim("username", authentication.getName())
					  .claim("authorities", populateAuthorities(authentication.getAuthorities()))
					  .setIssuedAt(new Date())
					.setExpiration(new Date((new Date()).getTime() + 30000000))
					.signWith(key).compact();
			
			return jwt;
	    }
	    
	    public String extractUsername(Claims claims) { 
	    	return String.valueOf(claims.get("username")); 
	    }
	    
	    public String extractAutorities(Claims claims) { 
	    	return  (String) claims.get("authorities"); 
	    }

		/*
		 * public Boolean validateToken(String token, UserDetails userDetails) { final
		 * String username = extractUsername(token); return
		 * (username.equals(userDetails.getUsername()) && !isTokenExpired(token)); }
		 */
	    
	    private String populateAuthorities(Collection<? extends GrantedAuthority> collection) {
			Set<String> authoritiesSet = new HashSet<>();
	        for (GrantedAuthority authority : collection) {
	        	authoritiesSet.add(authority.getAuthority());
	        }
	        return String.join(",", authoritiesSet);
		}
}
