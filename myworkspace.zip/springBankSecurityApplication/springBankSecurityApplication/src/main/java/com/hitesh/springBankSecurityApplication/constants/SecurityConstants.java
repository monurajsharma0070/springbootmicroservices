package com.hitesh.springBankSecurityApplication.constants;

public class SecurityConstants {

	public static final String JWT_KEY = "KKj5gC2T8tQKfQtqSGAyl6XELXbNvmm2XMYEy4PodyE=";
	public static final String JWT_HEADER = "Authorization"; 
}
