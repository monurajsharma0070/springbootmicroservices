package com.hitesh.springBankSecurityApplication.services;

import java.lang.reflect.Type;
import java.util.List;

import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.hitesh.springBankSecurityApplication.DTOModel.NoticeDTO;
import com.hitesh.springBankSecurityApplication.model.Notice;
import com.hitesh.springBankSecurityApplication.repository.NoticeRepository;
import com.hitesh.springBankSecurityApplication.utility.UtilityComponant;

@Service
public class NoticeServices {

	@Autowired
	private NoticeRepository noticeRepository;
	
	@GetMapping("/notices")
	public List<NoticeDTO> getNotices(String input) {
		
		List<Notice> notices=noticeRepository.findAllActiveNotices();
		if(!notices.isEmpty()) {
			 Type listType = new TypeToken<List<NoticeDTO>>(){}.getType();
			 List<NoticeDTO> noticesDTOList = UtilityComponant.getModelMapper().map(notices,listType);
			 return noticesDTOList;
		}else {
			
			return null;
		}
	}
}
