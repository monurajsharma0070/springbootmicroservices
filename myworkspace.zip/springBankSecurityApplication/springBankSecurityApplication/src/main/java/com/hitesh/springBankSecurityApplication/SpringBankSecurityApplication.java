package com.hitesh.springBankSecurityApplication;

import java.time.LocalDateTime;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@SpringBootApplication
@EnableJpaRepositories 
@EnableWebSecurity(debug = true)
@EnableGlobalMethodSecurity(prePostEnabled = true,securedEnabled = true,jsr250Enabled = true)
@EnableScheduling
@EnableTransactionManagement
public class SpringBankSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBankSecurityApplication.class, args);
	}
	
	@Scheduled(cron = "5 * * * * ?")
	public void scheduleTaskWithFixedRate() {
	    System.out.println("Fixed Rate Task :: Execution Time - {}"+ LocalDateTime.now());
	}

}
