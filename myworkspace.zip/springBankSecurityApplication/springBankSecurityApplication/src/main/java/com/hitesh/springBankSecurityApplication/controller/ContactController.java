package com.hitesh.springBankSecurityApplication.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreFilter;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.hitesh.springBankSecurityApplication.DTOModel.ContactDTO;
import com.hitesh.springBankSecurityApplication.services.ContactServices;

@RestController
public class ContactController {
	
	@Autowired
	private ContactServices contactServices;
	
	@PostMapping("/contact")
	//@PostFilter("filterObject.contactEmail == 'hitesh2@gmail.com' ")
	@PreFilter("filterObject.contactName == 'hitesh'")
	public ContactDTO saveContactInquiryDetails(@RequestBody ContactDTO contact) {
		return contactServices.saveContactInquiryDetails(contact);
	} 

}
