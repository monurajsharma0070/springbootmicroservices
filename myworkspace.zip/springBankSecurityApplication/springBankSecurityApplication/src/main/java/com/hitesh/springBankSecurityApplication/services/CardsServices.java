package com.hitesh.springBankSecurityApplication.services;

import java.lang.reflect.Type;
import java.util.List;

import org.modelmapper.TypeToken;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hitesh.springBankSecurityApplication.DTOModel.AccountsDTO;
import com.hitesh.springBankSecurityApplication.DTOModel.CardsDTO;
import com.hitesh.springBankSecurityApplication.model.Cards;
import com.hitesh.springBankSecurityApplication.repository.CardsRepository;
import com.hitesh.springBankSecurityApplication.utility.UtilityComponant;

@Service
public class CardsServices {
 
	@Autowired
	private CardsRepository cardsRepository;
	
    public List<CardsDTO> getAllCards(int id) {		
		List<Cards> cardsList=cardsRepository.findByCustomerId(id);
		if(!cardsList.isEmpty()) { 
		  Type listType = new TypeToken<List<CardsDTO>>(){}.getType();
		  List<CardsDTO> CardsDTOList = UtilityComponant.getModelMapper().map(cardsList,listType);
		  return CardsDTOList;	
		}else
		return null;
	}
    
    public CardsDTO getCardDetails(String cardNo) {
    	
    	 Cards cards=cardsRepository.findByCardNumber(cardNo);
    	 if(cards!=null)
    	 {
    		 CardsDTO cardsDTO=UtilityComponant.getModelMapper()
    				 .map(cards, CardsDTO.class); 
    		 return cardsDTO;
    	 }else
    		 return null;
		/*
		 * List<Cards> cardsList=cardsRepository.findByCustomerId(id);
		 * if(!cardsList.isEmpty()) { Type listType = new
		 * TypeToken<List<CardsDTO>>(){}.getType(); List<CardsDTO> CardsDTOList =
		 * UtilityComponant.getModelMapper().map(cardsList,listType); return
		 * CardsDTOList; }else return null;
		 */
	}
}
