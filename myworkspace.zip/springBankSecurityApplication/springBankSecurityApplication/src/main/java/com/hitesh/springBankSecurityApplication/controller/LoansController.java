package com.hitesh.springBankSecurityApplication.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.hitesh.springBankSecurityApplication.DTOModel.CustomerDTO;
import com.hitesh.springBankSecurityApplication.DTOModel.LoansDTO;
import com.hitesh.springBankSecurityApplication.model.Customer;
import com.hitesh.springBankSecurityApplication.model.Loans;
import com.hitesh.springBankSecurityApplication.repository.LoanRepository;
import com.hitesh.springBankSecurityApplication.services.LoansServices;

@RestController
public class LoansController {
	
	@Autowired
	private LoansServices loanServices;
	
	@PostMapping("/myLoans")
	@PreAuthorize("hasRole('USER')")
	public List<LoansDTO> getLoanDetails(@RequestBody CustomerDTO customer) {
		List<LoansDTO> loans = loanServices.getLoanDetails(customer.getId());
		if (loans != null ) {
			return loans;
		}else {
			return null;
		} 
	}

}