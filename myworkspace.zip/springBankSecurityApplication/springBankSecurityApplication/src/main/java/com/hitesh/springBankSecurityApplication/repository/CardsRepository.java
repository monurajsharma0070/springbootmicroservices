package com.hitesh.springBankSecurityApplication.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.repository.query.QueryByExampleExecutor;

import com.hitesh.springBankSecurityApplication.model.Cards;

public interface CardsRepository extends CrudRepository<Cards,Long>,QueryByExampleExecutor<Cards>{

	List<Cards> findByCustomerId(int customerId);
	
	@Query(value="select * from Cards where card_number = :cardnos",nativeQuery = true)
	Cards findByCardNumber(@Param("cardnos") String cardnos);
}
