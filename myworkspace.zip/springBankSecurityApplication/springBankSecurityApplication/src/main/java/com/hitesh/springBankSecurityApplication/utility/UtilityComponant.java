package com.hitesh.springBankSecurityApplication.utility;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class UtilityComponant {
	
	@Autowired
	private JwtUtil jwtTokenUtil;
	
	public static ModelMapper getModelMapper()
	{
		return new ModelMapper(); 
	}
	
	public JwtUtil getJwtUtilInstance()
	{
		return jwtTokenUtil;
	}

}
